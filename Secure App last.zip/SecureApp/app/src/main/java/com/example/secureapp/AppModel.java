package com.example.secureapp;

public class AppModel {
    public String packageName;
    public String appName;
    public String appPath;
    public String appType;

    //Constructor
    public AppModel(String packageName, String appName, String appPath, String appType) {
        this.packageName = packageName;
        this.appName = appName;
        this.appPath = appPath;
        this.appType = appType;
    }

    //Setters
    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public void setAppPath(String appPath) {
        this.appPath = appPath;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    //Getters
    public String getPackageName() {
        return packageName;
    }

    public String getAppName() {
        return appName;
    }

    public String getAppPath() {
        return appPath;
    }

    public String getAppType() {
        return appType;
    }




}
