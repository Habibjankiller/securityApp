package com.example.secureapp;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.AppLaunchChecker;
import androidx.core.app.NotificationCompat;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;
import com.bumptech.glide.Glide;
import com.google.android.ads.nativetemplates.TemplateView;
import com.rvalerio.fgchecker.AppChecker;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ForegroundService extends Service {
    private static final String ALGO = "MD5";
    public static int FOREGROUND_SERVICE_ID = 124;
    public static String FOREGROUND_NOTIFICATION_CHANNEL_ID = "foreground_notification";
    NotificationManager notificationManager;
    NotificationChannel notificationChannel;
    Notification foregroundNotification;
    PendingIntent pendingIntentNotification;
    Intent notificationIntent;
    private String encryptedPasswordFromDb;
    public static String currentWallpaperLocation = "none";
    ExecutorService executorService;
    private IntentFilter intentFilter;
    private BroadcastReceiver broadcastReceiver;
    private AppInfoDbHelper appInfoDbHelper;
    private SQLiteDatabase sqLiteDatabase;
    public static String lock_type = "";
    Handler lockHandler;
    private Timer timer = new Timer();
    ArrayList<String> lockedApps = new ArrayList<>();
    //Overlay Objects
    WindowManager windowManager;

    Timer patternLockTimer = new Timer();
    private static int isPatternLockTimer = 0;

    View lockView;
    WindowManager.LayoutParams layoutParams;
    int LAYOUT_FLAG;

    //FLAGS For Application Query
    private int APPLICATION_OPENED = 0;
    private String opened_app = "";
    public static String unlockedApp = "";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate() {
        super.onCreate();
        initalizeVariables();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        foregroundNotification = new NotificationCompat.Builder(this, FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setContentIntent(pendingIntentNotification)
                .setContentText("Securing Your App")
                .setChannelId(FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setOngoing(true)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(getResources().getString(R.string.app_name)).build();
        setLockView(lock_type);



        //Foreground App Checker
        AppChecker appChecker = new AppChecker();
        if (lockedApps != null){
            appChecker.whenAny(new AppChecker.Listener() {
                @Override
                public void onForeground(String process) {
                    if (!(opened_app.equals(process)) && !(process.equals(getPackageName()))){
                        opened_app = process;
                        Log.d("backgroundtask", process);
                        if (lockedApps.contains(process)){

                            if (process.equals("com.android.settings")) {
                                Intent lockIntent;
                                lockHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        lockView.setVisibility(View.INVISIBLE);
                                    }
                                });
                                if (lock_type.equals("pin")) {
                                    lockIntent = new Intent(getApplicationContext(), PinAuthenticationActivity.class);
                                    //SET ACTIVITY FLAGS
                                    lockIntent.setFlags(
                                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                                                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                                    Intent.FLAG_ACTIVITY_NEW_TASK |
                                                    Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
                                                    Intent.FLAG_FROM_BACKGROUND
                                    );
                                } else {
                                    lockIntent = new Intent(getApplicationContext(), PatternAuthenticationActivity.class);
                                    lockIntent.setFlags(
                                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                                                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                                    Intent.FLAG_ACTIVITY_NEW_TASK |
                                                    Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
                                                    Intent.FLAG_FROM_BACKGROUND
                                    );
                                }
                                lockIntent.putExtra("openedApp", opened_app);
                                APPLICATION_OPENED = 1;
                                Log.d("backgroundtask", "Starting Auth Activity");
                                startActivity(lockIntent);
                                //RUN LOCK ACTIVITY
                            } else {
                                activateLock();
                            }
//                            activateLock();
//                            Log.d("backgroundtask", "Activating lock");
                        }else{
                            deactivateLock();
                        }
                    }
                }
            })
                    .timeout(300)
                    .start(getApplicationContext());
        }

//        executorService.execute(new Runnable() {
//            @Override
//            public void run() {
//                if (Looper.myLooper() == null){
//                    Looper.prepare();
//                }
//                timer = new Timer();
//                timer.scheduleAtFixedRate(new TimerTask() {
//                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
//                    @Override
//                    public void run() {
//
//                        /*
//                        Getting Application Infoes from UsageStatsManager
//                         */
//                        String result = null;
//                        String runningApp = getRunningApplication();
//                        if (runningApp != null){
//                            Log.d("backgroundtask", runningApp);
//                            if (!(opened_app.equals(runningApp)) && !(runningApp.equals(unlockedApp))  && !(runningApp.equals("com.android.systemui"))){
//                                opened_app = runningApp;
//                                String SQL_SELECT_APP_QUERY = "SELECT "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME +" FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME+" WHERE "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME+" = '" + runningApp+"'";
//                                Cursor cursor = sqLiteDatabase.rawQuery(SQL_SELECT_APP_QUERY, new String[]{});
//                                if (cursor.getCount() > 0){
//                                    cursor.moveToNext();
//                                    result = cursor.getString(0);
//                                }
//
//                                if (runningApp.equals(result)) {
//        if (runningApp.equals("com.android.settings")) {
//            lockHandler.post(new Runnable() {
//                @Override
//                public void run() {
//                    lockView.setVisibility(View.INVISIBLE);
//                }
//            });
//            if (lock_type.equals("pin")) {
//                lockIntent = new Intent(getApplicationContext(), PinAuthenticationActivity.class);
//                //SET ACTIVITY FLAGS
//                lockIntent.setFlags(
//                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
//                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
//                                Intent.FLAG_ACTIVITY_NEW_TASK |
//                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
//                                Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
//                                Intent.FLAG_FROM_BACKGROUND
//                );
//            } else {
//                lockIntent = new Intent(getApplicationContext(), PatternAuthenticationActivity.class);
//                lockIntent.setFlags(
//                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
//                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
//                                Intent.FLAG_ACTIVITY_NEW_TASK |
//                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
//                                Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
//                                Intent.FLAG_FROM_BACKGROUND
//                );
//                //SET ACTIVITY FLAGS
//            }
//            lockIntent.putExtra("openedApp", opened_app);
//            APPLICATION_OPENED = 1;
//            Log.d("backgroundtask", "Starting Auth Activity");
//            startActivity(lockIntent);
//            //RUN LOCK ACTIVITY
//        } else {
//            activateLock();
//        }
//
//                                }
//                                    activateLock();
//                                }else{
//                                    deactivateLock();
//                                }
//                            }
//                        }
//                    }
//                }, 0, 300);

//                timer.scheduleAtFixedRate(new TimerTask() {
//                    @Override
//                    public void run() {
//                        changeAd();
//                    }
//                }, 0, 15000);
//
//        }});
        startForeground(FOREGROUND_SERVICE_ID, foregroundNotification);
        return START_STICKY;
    }

//    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
//    private String getRunningApplication () {
//            Long endTime = System.currentTimeMillis();
//            Long beginTime = endTime - 1000;
//            UsageEvents usageEvents = usageStatsManager.queryEvents(beginTime, endTime);
//            UsageEvents.Event event = new UsageEvents.Event();
//
//            while (usageEvents.hasNextEvent()){
//                usageEvents.getNextEvent(event);
//                if (event.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED){
//                    return event.getPackageName();
//                }
//            }
//        return null;
//    }

    private void deactivateLock () {
        lockHandler.post(new Runnable() {
            @Override
            public void run() {
                if (lockView.getVisibility() == View.VISIBLE){
                    lockView.setVisibility(View.INVISIBLE);
                }
            }
        });
        if (lock_type.equals("pin")){

            lockHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (lockView.getParent() != null){
                        EditText editText = lockView.findViewById(R.id.pinVerify);
                        editText.setText("");
                    }
                }
            });
        }

        unlockedApp = null;
    }

    private void activateLock () {
//        ImageView imageView  = lockView.findViewById(R.id.appIcon);

        lockHandler.post(new Runnable() {
            @Override
            public void run() {
//                try {
//                    Drawable drawable = getPackageManager().getApplicationIcon(opened_app);
//                    imageView.setImageDrawable(drawable);
//                } catch (PackageManager.NameNotFoundException e) {
//                    Toast.makeText(ForegroundService.this, "No App Icon Found", Toast.LENGTH_SHORT).show();
//                }
                lockView.setVisibility(View.VISIBLE);
            }
        });
        APPLICATION_OPENED = 1;
    }

    private void changeAd () {
        TemplateView templateView = lockView.findViewById(R.id.overlay_template_view);
        lockHandler.post(new Runnable() {
            @Override
            public void run() {
                ((MyApplication) getApplicationContext()).loadAndShowNativeAd(lockView, templateView);
            }
        });
    }

    private void setLockView (String string) {
        if (string.equals("pin")){
            lockView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pin_lock_authentication_overlay, null, false);
            lockHandler.post(new Runnable() {
                @Override
                public void run() {
                    lockHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            lockView.setVisibility(View.INVISIBLE);
                        }
                    });
                    windowManager.addView(lockView, layoutParams);
                }
            });
            GridLayout gridView = lockView.findViewById(R.id.numbersGridView);
            EditText editText = lockView.findViewById(R.id.pinVerify);
            ImageView imageView = lockView.findViewById(R.id.donePin);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String encryptedText = encryptText(editText.getText().toString());
                    String SQL_QUERY = "SELECT "+ AppInfoDbHelper.HashEntry.COLUME_HASHED +" FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
                    Cursor cursor = sqLiteDatabase.rawQuery(SQL_QUERY, null);
                    if (cursor.getCount() > 0){
                        cursor.moveToNext();
                        if (cursor.getString(0).equals(encryptedText)){
                            deactivateLock();
                        }
                    }else{
                        lockHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(ForegroundService.this, "Lock Not setted", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            });
            Button clearButton = lockView.findViewById(R.id.clearButton);
            clearButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editText.setText("");
                }
            });
            ArrayList<View> views = getViewsByTag(gridView, "figureButton");
            for (View view: views){
                Button button = (Button) view;
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        editText.setText(editText.getText().toString() + button.getText().toString());
                    }
                });
            }
        }else{
            lockView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pattern_lock_authentication_overlay, null, false);
            ImageView appIcon = lockView.findViewById(R.id.appIcon);
            ImageView imageView = lockView.findViewById(R.id.overlay_background);
            TemplateView templateView = lockView.findViewById(R.id.overlay_template_view);
            ((MyApplication) getApplicationContext()).loadAndShowNativeAd(lockView, templateView);
            SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
            Drawable currentWallpaperDrawable = Drawable.createFromPath(currentWallpaperLocation);
            lockHandler.post(new Runnable() {
                @Override
                public void run() {
                    Glide.with(getApplicationContext()).load(currentWallpaperDrawable).centerCrop().into(imageView);
                }
            });
            PatternLockView patternLockView = lockView.findViewById(R.id.unlockAppPatternView);

            try {
                //Get modificatiton Here
                appIcon.setImageDrawable(getPackageManager().getApplicationIcon(opened_app));
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            String SQL_GET_HASHED_PASSWORD = "SELECT "+ AppInfoDbHelper.HashEntry.COLUME_HASHED+" FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
            Cursor cursor = sqLiteDatabase.rawQuery(SQL_GET_HASHED_PASSWORD, null);
            if (cursor.getCount() > 0) {
                cursor.moveToNext();
                encryptedPasswordFromDb = cursor.getString(0);
            }

            patternLockView.setDotCount(3);
            patternLockView.setAspectRatioEnabled(true);
            patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
            patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
            patternLockView.setDotAnimationDuration(150);
            patternLockView.setPathEndAnimationDuration(100);
            patternLockView.setInStealthMode(sharedPreferences.getBoolean("pattern_visible", false));
            patternLockView.setTactileFeedbackEnabled(true);
            patternLockView.setInputEnabled(true);
            patternLockView.addPatternLockListener(new PatternLockViewListener() {
                @Override
                public void onStarted() {
                    if (isPatternLockTimer == 1){
                        patternLockTimer.cancel();
                        isPatternLockTimer = 0;
                    }

                }

                @Override
                public void onProgress(List<PatternLockView.Dot> progressPattern) {

                }

                @Override
                public void onComplete(List<PatternLockView.Dot> pattern) {
                    if (pattern.size() < 4){
                        Toast.makeText(getApplicationContext(), "Draw Four", Toast.LENGTH_SHORT).show();
                        patternLockView.clearPattern();
                    }else{
                        String patternToMD5 = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        if (encryptedPasswordFromDb.equals(patternToMD5)){
                            lockHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    lockView.setVisibility(View.INVISIBLE);
                                    patternLockView.clearPattern();
                                }
                            });
                        }else{
                            patternLockView.setViewMode(PatternLockView.PatternViewMode.WRONG);
                            patternLockTimer.schedule(new TimerTask() {
                                @Override
                                public void run() {
                                    isPatternLockTimer = 1;
                                    lockHandler.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            patternLockView.clearPattern();
                                            isPatternLockTimer = 0;
                                        }
                                    });
                                }
                            }, 800);
                        }
                    }
                }

                @Override
                public void onCleared() {

                }
            });

            lockHandler.post(new Runnable() {
                @Override
                public void run() {
                    lockHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            lockView.setVisibility(View.INVISIBLE);
                        }
                    });
                    if (lockView.getParent() != null){
                        windowManager.removeView(lockView);
                        windowManager.addView(lockView, layoutParams);
                    }else{
                        lockView.setVisibility(View.GONE);
                        windowManager.addView(lockView, layoutParams);
                    }

                }
            });
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onDestroy() {
        super.onDestroy();

        if (lockView.isAttachedToWindow()){
            windowManager.removeView(lockView);
        }
        startService(new Intent(this, ForegroundService.class));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void initalizeVariables () {
        executorService = Executors.newFixedThreadPool(10);
        lock_type = getSharedPreferences(
                getResources().getString(R.string.myAppSharedPreferences),
                Context.MODE_PRIVATE)
                .getString("lock_type", "none");
        windowManager = (WindowManager) getSystemService(Service.WINDOW_SERVICE);
        currentWallpaperLocation = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE).getString("currentWallpaperLocation", "none");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }
        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION |
                        WindowManager.LayoutParams.FLAG_DIM_BEHIND |
                        WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
        );

        lockHandler = new Handler();
        notificationIntent = new Intent(this, MainActivity.class);
        intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_USER_PRESENT);
        intentFilter.addAction(Intent.ACTION_USER_UNLOCKED);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        broadcastReceiver = new startForegroundAfterDeviceBoot();
        getApplicationContext().registerReceiver(broadcastReceiver, intentFilter);
        pendingIntentNotification = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        appInfoDbHelper = new AppInfoDbHelper(getBaseContext());
        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
//        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationChannel = new NotificationChannel(
                    FOREGROUND_NOTIFICATION_CHANNEL_ID,
                    "Notification Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            usageStatsManager = (UsageStatsManager) getBaseContext().getSystemService(Context.USAGE_STATS_SERVICE);
//        }
    }

    private static ArrayList<View> getViewsByTag(ViewGroup root, String tag){
        ArrayList<View> views = new ArrayList<View>();
        final int childCount = root.getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View child = root.getChildAt(i);
            if (child instanceof ViewGroup) {
                views.addAll(getViewsByTag((ViewGroup) child, tag));
            }

            final Object tagObj = child.getTag();
            if (tagObj != null && tagObj.equals(tag)) {
                views.add(child);
            }

        }
        return views;
    }



    public static String encryptText (String message){
        MessageDigest passEncrypytor;
        passEncrypytor = null;
        try {
            passEncrypytor = MessageDigest.getInstance(ALGO);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        passEncrypytor.update(message.getBytes());
        byte[] digest = passEncrypytor.digest();
        StringBuffer hexString = new StringBuffer();
        for (int i=0; i<digest.length; i++)
            hexString.append(Integer.toHexString(0xFF & digest[i]));
        Log.d("encryption", hexString.toString());

        return hexString.toString();
    }
}
