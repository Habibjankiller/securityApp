package com.example.secureapp;

import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import com.google.android.gms.internal.ads.zzath;
import com.google.common.net.HttpHeaders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.locks.Lock;

public abstract class GlobalClass {

    public static ArrayList<String> importantAppsPackageNames(PackageManager packageManager) {
        ArrayList<String> importantAppsPackageNameArrayList = new ArrayList<>();
        for (ApplicationInfo application: availableImportantApps(packageManager)){
            importantAppsPackageNameArrayList.add(application.packageName);
        }

        return importantAppsPackageNameArrayList;
    }

    public static boolean isOverLayGranted(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(context)){
                return true;
            }
        }else{
            return false;
        }
        return false;
    }

    public boolean setDefaultPreferences (SharedPreferences sharedPreferences, Context context) {
        try {
            sharedPreferences.edit().putBoolean(context.getString(R.string.intruder_detection_preference), false).apply();
            sharedPreferences.edit().putBoolean(context.getString(R.string.random_animation_preference), false).apply();
            sharedPreferences.edit().putBoolean(context.getString(R.string.apply_cover_preference), false).apply();
            sharedPreferences.edit().putBoolean(context.getString(R.string.pattern_hide_preference), false).apply();
            sharedPreferences.edit().putBoolean(context.getString(R.string.vibrate_touch_preference), false).apply();
            sharedPreferences.edit().putBoolean(context.getString(R.string.app_locker_opened), false).apply();
            return true;
        }catch (Exception e){
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void checkPermissionAndStartPermit (PackageManager packageManager, Context context) {
        if (!(isUsageAccessGranted(context, packageManager)) || !(isOverLayGranted(context))){
            Intent intent = new Intent(context, PermissionCheckingActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static boolean startSecurity(Context context, PackageManager packageManager, SharedPreferences sharedPreferences) {
        if (GlobalClass.isRequiredPermissionGranted(context, packageManager)){
            Intent serviceIntent = new Intent(context, ForegroundService.class);
            if (GlobalClass.isServiceRunFirstTime(sharedPreferences)){
                ContextCompat.startForegroundService(context, serviceIntent);
            }else{
                ContextCompat.startForegroundService(context, serviceIntent);
            }
            return true;
        }

        return false;
    }

    public static ArrayList<ApplicationInfo> getAllApps(PackageManager packageManager) {

        ArrayList<ApplicationInfo> allApps = (ArrayList<ApplicationInfo>) packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
        ArrayList<ApplicationInfo> filteredApps = new ArrayList<>();
        ArrayList<String> importantAppsPackageName = importantAppsPackageNames(packageManager);
        for (ApplicationInfo applicationInfo: allApps){
            //Getting only filter application (Applications with Launcher Intent);
            if (packageManager.getLaunchIntentForPackage(applicationInfo.packageName) != null){
                if (importantAppsPackageName.contains(applicationInfo.packageName)){
                    continue;
                }else{
                    filteredApps.add(applicationInfo);
                }
            }
        }

        return filteredApps;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static boolean isRequiredPermissionGranted(Context context, PackageManager packageManager){
        if (!(isUsageAccessGranted(context, packageManager)) || !(isOverLayGranted(context))){
            return false;
        }else{
            return true;
        }
    }

    public static boolean isServiceRunFirstTime(SharedPreferences sharedPreferences) {
        if (sharedPreferences.getBoolean("firstTimeServiceRun", false)){
            return true;
        }else{
            return false;
        }
    }
    public static void sortedAppList (ArrayList<ApplicationInfo> toSortApps, PackageManager packageManager) {
        if (Build.VERSION.SDK_INT >= 24){
            toSortApps.sort(new Comparator<ApplicationInfo>() {
                @Override
                public int compare(ApplicationInfo o1, ApplicationInfo o2) {
                    String firstAppName = o1.loadLabel(packageManager).toString();
                    String secondAppName = o2.loadLabel(packageManager).toString();
                    return String.CASE_INSENSITIVE_ORDER.compare(firstAppName, secondAppName);
                }
            });
        }else{
            Collections.sort(toSortApps, new Comparator<ApplicationInfo>() {
                @Override
                public int compare(ApplicationInfo o1, ApplicationInfo o2) {
                    String firstAppName = o1.loadLabel(packageManager).toString();
                    String secondAppName = o2.loadLabel(packageManager).toString();
                    return String.CASE_INSENSITIVE_ORDER.compare(firstAppName, secondAppName);
                }
            });
        }
    }

    public static ArrayList<ApplicationInfo> availableImportantApps(PackageManager packageManager) {
        ArrayList<String> importantAppList = new ArrayList<>();
        importantAppList.add("com.facebook.katana");
        importantAppList.add("com.whatsapp");
        importantAppList.add("com.android.settings");

        ArrayList<ApplicationInfo> availableImportantApps = new ArrayList<>();
        for (String app: importantAppList){
            try {
                ApplicationInfo checkedApplication = packageManager.getApplicationInfo(app, 0);
                availableImportantApps.add(checkedApplication);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }
        return availableImportantApps;
    }

    public static void selectTab (Context context, LinearLayout linearLayout, TextView textView) {
        linearLayout.setBackgroundColor(context.getResources().getColor(R.color.white));
        textView.setTextColor(context.getResources().getColor(R.color.colorPrimaryDark));
        linearLayout.setClickable(false);
    }
    public static void unSelectTab(Context context, LinearLayout linearLayout, TextView textView){
        linearLayout.setBackgroundColor(context.getResources().getColor(R.color.transparent));
        textView.setTextColor(context.getResources().getColor(R.color.white));
        linearLayout.setClickable(true);
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static boolean isUsageAccessGranted(Context context, PackageManager packageManager) {

        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.KITKAT) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
