package com.example.secureapp;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class LockAppsViewModel extends AndroidViewModel {
    private AppRepository appRepository;
    private LiveData<List<LockApp>> lockAppsList;
    public LockAppsViewModel(@NonNull Application application) {
        super(application);
        appRepository = new AppRepository(application);
        lockAppsList = appRepository.getAllLockApps();
    }

    public void insertApp (LockApp lockApp) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (getAppByPackageName(lockApp.appPackageName) == null){
                    appRepository.insertAppToDatabase(lockApp);
                }
            }
        }).start();
    }

    public void delete (String appPackageName){
        appRepository.deleteAppFromDatabase(appPackageName);
    }

    public void deleteAllApps () {
        appRepository.deleteAllApps();
    }

    public LockApp getAppByPackageName (String appPackageName) {
        return appRepository.getAppFromDatabase(appPackageName);
    }

    public LiveData<List<LockApp>> getLockAppsList () {
        if (lockAppsList == null){
            lockAppsList = appRepository.getAllLockApps();
        }

        return lockAppsList;
    }
}
