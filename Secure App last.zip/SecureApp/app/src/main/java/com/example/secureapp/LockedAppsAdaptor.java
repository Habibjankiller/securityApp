package com.example.secureapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LockedAppsAdaptor extends RecyclerView.Adapter<LockedAppsAdaptor.ViewHolder> {
    ArrayList<ApplicationInfo> lockedApplicationInfos;
    Context context;
    PackageManager packageManager;
    SQLiteDatabase sqLiteDatabase;

    public LockedAppsAdaptor(Context context, ArrayList<ApplicationInfo> lockedApplicationInfos, PackageManager packageManager, SQLiteDatabase sqLiteDatabase) {
        this.lockedApplicationInfos = lockedApplicationInfos;
        this.context = context;
        this.packageManager = packageManager;
        this.sqLiteDatabase = sqLiteDatabase;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.app_list_item_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApplicationInfo applicationInfo = lockedApplicationInfos.get(position);
        String appName = applicationInfo.loadLabel(packageManager).toString();
        String packagName = applicationInfo.packageName;
        Drawable iconDrawable = null;
        Drawable lockDrawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.locked_toggle, null);
        Drawable unlockDrawable = ResourcesCompat.getDrawable(context.getResources(), R.drawable.unlock_toggle, null);
        try {
            iconDrawable = packageManager.getApplicationIcon(packagName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        //Setting Resources to View
        holder.app_name.setText(appName);
        holder.appIcon.setImageDrawable(iconDrawable);
        holder.statusSwitch.setImageDrawable(lockDrawable);
        if (isLocked(appName, packagName)){
            holder.statusSwitch.setImageDrawable(lockDrawable);
        }else{
            holder.statusSwitch.setImageDrawable(unlockDrawable);
        }
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLocked(appName, packagName)){
                    try {
                        deleteAppFromDatabase(packagName);
                        Toast.makeText(context, "App Deleted", Toast.LENGTH_SHORT).show();
                        holder.statusSwitch.setImageDrawable(unlockDrawable);
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                }else{
                    try {
                        insertAppToDatabase(packagName, sqLiteDatabase);
                        holder.statusSwitch.setImageDrawable(lockDrawable);
                        Toast.makeText(context, "App is locked", Toast.LENGTH_SHORT).show();
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return lockedApplicationInfos.size();
    }

    public static class ViewHolder extends RecyclerViewAdaptor.ViewHolder{
        RelativeLayout relativeLayout;
        ImageView appIcon;
        TextView app_name;
        ImageView statusSwitch;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            relativeLayout = itemView.findViewById(R.id.relative_layout);
            appIcon = itemView.findViewById(R.id.app_icon);
            app_name = itemView.findViewById(R.id.app_name);
            statusSwitch = itemView.findViewById(R.id.lock_switch);
        }
    }

    public boolean isLocked (String appName, String packageName){
        Cursor appSearchResult = sqLiteDatabase.rawQuery(
                "SELECT ? FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME +" " +
                        "WHERE "+ AppInfoDbHelper.AppEntry.COLUMN_APP_NAME+" = ? AND "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME + " = ?",
                new String[] {AppInfoDbHelper.AppEntry.COLUMN_ISLOCKED, appName, packageName});
        if (appSearchResult.moveToNext()){
            return true;
        }else{
            return false;
        }
    }

    public int deleteAppFromDatabase (String appPackageName) throws PackageManager.NameNotFoundException {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(appPackageName, PackageManager.GET_META_DATA);
        String appName = applicationInfo.loadLabel(packageManager).toString();

        int deleteQuery = sqLiteDatabase.delete(
                AppInfoDbHelper.AppEntry.TABLE_NAME,
                AppInfoDbHelper.AppEntry.COLUMN_APP_NAME +" = ? AND "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME +" = ?",
                new String[] {appName, appPackageName});

        return deleteQuery;
    }

    public boolean insertAppToDatabase (String appPackageName, SQLiteDatabase sqLiteDatabase) throws PackageManager.NameNotFoundException {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(appPackageName, PackageManager.GET_META_DATA);
        String appName = applicationInfo.loadLabel(packageManager).toString();
        ContentValues contentValues = new ContentValues();
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_APP_NAME, appName);
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME, appPackageName);
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_ISLOCKED, "true");
        sqLiteDatabase.insert(AppInfoDbHelper.AppEntry.TABLE_NAME, null, contentValues);
        return true;
    }
}
