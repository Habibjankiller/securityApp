package com.example.secureapp;

import androidx.lifecycle.LifecycleService;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LockedAppsDao {


    @Query("SELECT * FROM locked_apps")
    public LiveData<List<LockApp>> getAllLockedApps();

    @Query("SELECT * FROM locked_apps WHERE app_name LIKE :name LIMIT 1")
    public LockApp getLockAppByPackageName(String name);

    @Query("SELECT * FROM locked_apps WHERE app_name LIKE :packageName LIMIT 1")
    public LockApp getLockAppByName(String packageName);

    @Insert
    public void insertApps(LockApp... lockAppEntities);

    @Delete
    public void deleteLockApp(LockApp lockAppEntity);

    @Query("DELETE FROM locked_apps")
    public void deleteAllApps ();

}