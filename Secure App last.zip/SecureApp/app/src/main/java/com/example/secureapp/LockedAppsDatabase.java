package com.example.secureapp;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {LockApp.class}, version = 1)
public abstract class LockedAppsDatabase extends RoomDatabase {
    private static LockedAppsDatabase lockedAppsDatabase;
    public abstract LockedAppsDao lockAppsDao ();

    public static LockedAppsDatabase getInstance(Context context) {
        if (lockedAppsDatabase == null){
            lockedAppsDatabase = Room.databaseBuilder(context,
                    LockedAppsDatabase.class,
                    context.getResources().getString(R.string.database_name))
                    .enableMultiInstanceInvalidation().build();
            return lockedAppsDatabase;
        }else{
            return lockedAppsDatabase;
        }
    }
}
