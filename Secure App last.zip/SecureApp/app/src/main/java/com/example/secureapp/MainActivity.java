package com.example.secureapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.room.Room;
import androidx.viewpager.widget.ViewPager;
import androidx.work.WorkManager;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    public static boolean isFirstRun = true;


    //Rewarded Ads variables
    RewardedAd rewardAd;


    //Application Info Variables
    PackageManager packageManager;
//    MyApplication myApplication;

    //tab layout
    LinearLayout all_apps_tab_layout;
    LinearLayout lock_apps_tab_layout;
    TextView all_apps_tab_text;
    TextView lock_apps_tab_text;

    //ViewPager Setup Variables
    ViewPagerAdaptor viewPagerAdaptor;
    NoScrollingViewPager viewPager;

//    //Database Instance Variable
    LockedAppsDatabase lockedAppsDatabase;
    LockedAppsDao lockedAppsDao;
//    AppInfoDbHelper appInfoDbHelper;
//    SQLiteDatabase sqLiteDatabase;

    //Global Application Class
    MyApplication myApplication;

    //WorkManager
    WorkManager workManager;

    //SharedPreferences
    SharedPreferences sharedPreferences;
    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_SecureApp);
        super.onCreate(savedInstanceState);
//        myApplication = GlobalClass;
//        appInfoDbHelper = new AppInfoDbHelper(getApplicationContext());
//        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();


        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        //Creating Layout
        setContentView(R.layout.activity_main);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                lockedAppsDatabase = LockedAppsDatabase.getInstance(getApplicationContext());
                lockedAppsDao = lockedAppsDatabase.lockAppsDao();
            }
        });
        //Referense to TAB
        all_apps_tab_layout = findViewById(R.id.all_apps_tab_layout);
        lock_apps_tab_layout = findViewById(R.id.lock_apps_tab_layout);

        all_apps_tab_text = findViewById(R.id.all_apps_tab_text);
        lock_apps_tab_text = findViewById(R.id.lock_apps_tab_text);

        //Variable Initialization
//        tabLayout = findViewById(R.id.tab_layout);
        packageManager = getPackageManager();
        viewPagerAdaptor = new ViewPagerAdaptor(getSupportFragmentManager());
        viewPager = findViewById(R.id.all_apps_view_pager);
        Handler handler = new Handler();
        all_apps_tab_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GlobalClass.selectTab(getApplicationContext(), all_apps_tab_layout, all_apps_tab_text);
                GlobalClass.unSelectTab(getApplicationContext(), lock_apps_tab_layout, lock_apps_tab_text);
                viewPager.setCurrentItem(0);
            }
        });

        lock_apps_tab_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GlobalClass.selectTab(getApplicationContext(), lock_apps_tab_layout, lock_apps_tab_text);
                GlobalClass.unSelectTab(getApplicationContext(), all_apps_tab_layout, all_apps_tab_text);
                viewPager.setCurrentItem(1);
            }
        });
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0){
                    GlobalClass.selectTab(getApplicationContext(), all_apps_tab_layout, all_apps_tab_text);
                    GlobalClass.unSelectTab(getApplicationContext(), lock_apps_tab_layout, lock_apps_tab_text);
                }else{
                    GlobalClass.selectTab(getApplicationContext(), lock_apps_tab_layout, lock_apps_tab_text);
                    GlobalClass.unSelectTab(getApplicationContext(), all_apps_tab_layout, all_apps_tab_text);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        GlobalClass.selectTab(getApplicationContext(), all_apps_tab_layout, all_apps_tab_text);
        GlobalClass.unSelectTab(getApplicationContext(), lock_apps_tab_layout, lock_apps_tab_text);
        ExecutorService executorService = Executors.newSingleThreadExecutor();
//        if (!sharedPreferences.getBoolean(getString(R.string.app_locker_opened), false)){
//            try {
//                myApplication.insertAppToDatabase(myApplication.availableImportantApps(), sqLiteDatabase);
//                handler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(myApplication, "Important Apps Locked", Toast.LENGTH_SHORT).show();
//                        Log.d("backgroundtask", "important apps are locked");
//                    }
//                });
//                boolean result = myApplication.setDefaultPreferences();
//                if (result){
//                    handler.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            Toast.makeText(myApplication, "Default Settings Apply", Toast.LENGTH_LONG).show();
//                        }
//                    });
//                }
//            } catch (PackageManager.NameNotFoundException e) {
//                e.printStackTrace();
//            }
//        }


        viewPager.setAdapter(viewPagerAdaptor);
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                sharedPreferences.edit().putBoolean("appLockerOpened", true).apply();
            }
        });

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
//        startSecurity();
    }



    public void openSetting(View view) {
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);
    }





}