package com.example.secureapp;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.res.ResourcesCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyApplication extends Application implements LifecycleObserver {
    private PackageManager packageManager;
    //ForegroundService Variables
    //App SQLite Databse
    private AppInfoDbHelper appInfoDbHelper;
    private SQLiteDatabase sqLiteDatabase;
    private int numProtectedApps;
    public static String AdLog = "adLog";

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, initializationStatus -> {
        });
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

//    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    public void appInResumeState (){
        String appLock = getSharedPreferences(
                getResources().getString(R.string.myAppSharedPreferences),
                Context.MODE_PRIVATE)
                .getString("lock_type", "none");;
        if (!(appLock.equals("pin") || appLock.equals("pattern"))){
            Toast.makeText(this, "You are not yet configured the security", Toast.LENGTH_SHORT).show();
        }else{
            Intent lockIntent;

            if (appLock.equals("pin")) {
                lockIntent = new Intent(getApplicationContext(), PinAuthenticationActivity.class);
                //SET ACTIVITY FLAGS
//                lockIntent.setFlags(
//                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
//                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
//                                Intent.FLAG_ACTIVITY_NEW_TASK |
//                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
//                                Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
//                                Intent.FLAG_FROM_BACKGROUND
//                );
            } else {
                lockIntent = new Intent(getApplicationContext(), PatternAuthenticationActivity.class);
//                lockIntent.setFlags(
//                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
//                                Intent.FLAG_ACTIVITY_SINGLE_TOP |
//                                Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
//                                Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
//                                Intent.FLAG_FROM_BACKGROUND
//                );
            }
            lockIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            lockIntent.putExtra("openedApp", getPackageName());
            startActivity(lockIntent);
        }
    }

//    @OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    public void appInOffState () {

    }

    public void setImportantVariables() {
        appInfoDbHelper = new AppInfoDbHelper(getApplicationContext());
        sqLiteDatabase = appInfoDbHelper.getWritableDatabase();
        packageManager = getPackageManager();
    }


    public void requestAndLoadRewardedAd (Activity requiredActivity) {
        RewardedAdLoadCallback rewardedAdLoadCallback = new RewardedAdLoadCallback() {
            RewardedAd rewardAd = null;
            @Override
            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                super.onAdLoaded(rewardedAd);
                rewardAd = rewardedAd;
                rewardAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                        super.onAdFailedToShowFullScreenContent(adError);
                        Log.d("rewardedAdCallBack", "onAdFailedToShow");
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        super.onAdShowedFullScreenContent();
                        Log.d("rewardedAdCallBack", "onAdShowedFullScreenContent");
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        super.onAdDismissedFullScreenContent();
                        Log.d("rewardedAdCallBack", "onAdDismissedFullScreenContent");
                    }
                });

                if (rewardAd != null){
                    Activity activity = requiredActivity;
                    rewardAd.show(activity, new OnUserEarnedRewardListener() {
                        @Override
                        public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                            Toast.makeText(activity, "You earned something", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                Log.d("rewardedAd", "rewarded ad Loaded");
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                Log.d("rewardedAd", "rewarded ad failed to load");
                rewardAd = null;
            }
        };
        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(this, "ca-app-pub-3940256099942544/5224354917", adRequest, rewardedAdLoadCallback);
    }

    public void loadAndShowNativeAd (View fragmentView, TemplateView templateView) {
        AdRequest adRequest = new AdRequest.Builder().build();
        AdLoader adLoader = new AdLoader.Builder(getApplicationContext(), "ca-app-pub-3940256099942544/2247696110")
                .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                    @Override
                    public void onNativeAdLoaded(@NonNull NativeAd nativeAd) {
                        NativeTemplateStyle nativeTemplateStyle = new NativeTemplateStyle.Builder().build();
                        templateView.setStyles(nativeTemplateStyle);
                        templateView.setNativeAd(nativeAd);
                        if (templateView.getVisibility() == View.GONE){
                            templateView.setVisibility(View.VISIBLE);
                        }
                    }
                }).build();
        adLoader.loadAd(adRequest);
    }
}