package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;
import java.util.regex.Pattern;

public class PatternAuthenticationActivity extends AppCompatActivity {
    PatternLockView patternLockView;
    ImageView appIcon;
    String appPackageName;
    AppInfoDbHelper appInfoDbHelper;
    SQLiteDatabase sqLiteDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pattern_authentication);

        //Initilizing variables
        patternLockView = findViewById(R.id.unlockAppPatternView);
        appIcon = findViewById(R.id.appIcon);
        appPackageName = getIntent().getExtras().getString("openedApp");
        appInfoDbHelper = new AppInfoDbHelper(this);
        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();


        try {
            appIcon.setImageDrawable(getPackageManager().getApplicationIcon(appPackageName));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        final String[] encryptedPasswordFromDb = new String[1];
        String SQL_GET_HASHED_PASSWORD = "SELECT "+ AppInfoDbHelper.HashEntry.COLUME_HASHED+" FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(SQL_GET_HASHED_PASSWORD, null);
        if (cursor.getCount() > 0) {
            cursor.moveToNext();
            encryptedPasswordFromDb[0] = cursor.getString(0);
        }

        patternLockView.setDotCount(3);
        patternLockView.setAspectRatioEnabled(true);
        patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
        patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
        patternLockView.setDotAnimationDuration(150);
        patternLockView.setPathEndAnimationDuration(100);
        patternLockView.setInStealthMode(false);
        patternLockView.setTactileFeedbackEnabled(true);
        patternLockView.setInputEnabled(true);
        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if (pattern.size() < 4){
                    Toast.makeText(PatternAuthenticationActivity.this, "Draw Four", Toast.LENGTH_SHORT).show();
                    patternLockView.clearPattern();
                }else{
                    String patternToMD5 = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        if (encryptedPasswordFromDb[0].equals(patternToMD5)){
                            ForegroundService.unlockedApp = appPackageName;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                finishAndRemoveTask();
                            }else{
                                finish();
                            }
                        }else{
                            patternLockView.clearPattern();
                            Toast.makeText(PatternAuthenticationActivity.this, "Wrong Pattern Detected", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            @Override
            public void onCleared() {

            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}