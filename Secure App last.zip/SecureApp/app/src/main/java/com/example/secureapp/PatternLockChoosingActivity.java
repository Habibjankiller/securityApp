package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import org.w3c.dom.Text;

import java.util.List;
import java.util.regex.Pattern;

public class PatternLockChoosingActivity extends AppCompatActivity {
    private static final String ALGO = "MD5";
    PatternLockView patternLockView;
    private String tryFirst = "";
    private String trySecond = "";

    private boolean isFirst = true;
    TextView textView;

    //Database Variables
    AppInfoDbHelper sqLiteOpenHelper;
    SQLiteDatabase sqLiteDatabase;

    //SharedPreferences
    SharedPreferences sharedPreferences;
    private boolean passwordAlreadySetted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pattern_lock_choosing);
        patternLockView = findViewById(R.id.setting_pattern_lock);
        textView = findViewById(R.id.dialog_text_view);
        sqLiteOpenHelper = new AppInfoDbHelper(this);
        sqLiteDatabase = sqLiteOpenHelper.getWritableDatabase();
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        String SQL_QUERY = "SELECT * FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(SQL_QUERY, null);

        if (!(cursor.getCount() > 0)){
            passwordAlreadySetted = false;
        }else{
            passwordAlreadySetted = true;
        }
        patternLockView.setDotCount(3);
        patternLockView.setAspectRatioEnabled(true);
        patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
        patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
        patternLockView.setDotAnimationDuration(150);
        patternLockView.setPathEndAnimationDuration(100);
        patternLockView.setInStealthMode(false);
        patternLockView.setTactileFeedbackEnabled(true);
        patternLockView.setInputEnabled(true);
        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if (pattern.size() < 4){
                    patternLockView.clearPattern();
                }else{
                    if (isFirst){
                        tryFirst = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        textView.setText("Redraw pattern to confirm");
                        isFirst = false;
                        patternLockView.clearPattern();
                    }else{
                        trySecond = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        if (tryFirst.equals(trySecond)){
                            Toast.makeText(PatternLockChoosingActivity.this, "Pattern Match Successfully", Toast.LENGTH_SHORT).show();
                            ContentValues contentValues = new ContentValues();
                            contentValues.put(AppInfoDbHelper.HashEntry.COLUMN_HASH_TYPE, ALGO);
                            contentValues.put(AppInfoDbHelper.HashEntry.COLUME_HASHED, tryFirst);
                            if (!passwordAlreadySetted){
                                sqLiteDatabase.insert(AppInfoDbHelper.HashEntry.TABLE_NAME, null, contentValues);
                                Intent intent = new Intent(PatternLockChoosingActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }else{
                                sqLiteDatabase.update(AppInfoDbHelper.HashEntry.TABLE_NAME, contentValues, AppInfoDbHelper.HashEntry.COLUMN_HASH_TYPE +" = ?", new String[]{ALGO});
                            }
                            sharedPreferences.edit().putString("lock_type", "pattern").apply();
                            ForegroundService.lock_type = "pattern";
                            finish();
                        }else{
                            Toast.makeText(PatternLockChoosingActivity.this, "Pattern Not match Try Again", Toast.LENGTH_SHORT).show();
                            textView.setText("Draw an unlock pattern");
                        }

                        isFirst = true;
                        patternLockView.clearPattern();
                    }
                }
            }

            @Override
            public void onCleared() {

            }
        });
    }
}