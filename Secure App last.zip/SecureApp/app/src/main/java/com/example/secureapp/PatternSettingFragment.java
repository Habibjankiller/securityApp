package com.example.secureapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PatternSettingFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PatternSettingFragment extends Fragment {
    RelativeLayout change_pattern_layout;

    //Pattern Visibility Option
    RelativeLayout patternVisibilityLayout;
    ImageView patternVisibilitySwitch;

    //Input vibrate option
    RelativeLayout patternVibrateLayout;
    ImageView patternVibrateSwitch;

    //SharedPreferences
    private SharedPreferences sharedPreferences;
    boolean patternVisibilityStatus;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public PatternSettingFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PatternSettingFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static PatternSettingFragment newInstance(String param1, String param2) {
        PatternSettingFragment fragment = new PatternSettingFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pattern_setting, container, false);
        sharedPreferences = getActivity().getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        patternVisibilityStatus = sharedPreferences.getBoolean("pattern_visible", true);
        patternVisibilityLayout = view.findViewById(R.id.pattern_visibility_layout);
        patternVisibilitySwitch = view.findViewById(R.id.pattern_visibility_switch);

        patternVibrateLayout = view.findViewById(R.id.input_vibrate_layout);
        patternVibrateSwitch = view.findViewById(R.id.input_vibrate_switch);

        patternVisibilitySwitch = view.findViewById(R.id.pattern_visibility_switch);


        change_pattern_layout = view.findViewById(R.id.open_change_pattern_lock_layout);
        change_pattern_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplicationContext(), PatternLockChoosingActivity.class);
                startActivity(intent);
            }
        });
        if (patternVisibilityStatus){
            patternVisibilitySwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));
        }else{
            patternVisibilitySwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
        }


        patternVisibilityLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (togglePatternVisibility()){
                    patternVisibilitySwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));
                }else{
                    patternVisibilitySwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
                }

            }
        });
        return view;
    }

    public boolean togglePatternVisibility () {
        boolean result = true;
        if (patternVisibilityStatus){
            sharedPreferences.edit().putBoolean("pattern_visible", false).apply();
            patternVisibilityStatus = false;
            result = false;
        }else{
            sharedPreferences.edit().putBoolean("pattern_visible", true).apply();
            patternVisibilityStatus = true;
            result = true;
        }
        Intent serviceIntent = new Intent(getContext(), ForegroundService.class);
        getActivity().stopService(serviceIntent);
        ContextCompat.startForegroundService(getContext(), serviceIntent);
        return result;

    }

    public boolean toggleInputVibrate () {
        if (patternVisibilityStatus){
            sharedPreferences.edit().putBoolean("pattern_visible", false).apply();
            return false;
        }else{
            sharedPreferences.edit().putBoolean("pattern_visible", true).apply();
            return true;
        }
    }
}