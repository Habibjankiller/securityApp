package com.example.secureapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.audiofx.BassBoost;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;

public class PermissionCheckingActivity extends AppCompatActivity {
    CardView overlayCardView;
    CardView usagestats_card_view;
    Cursor cursor;
    AppInfoDbHelper appInfoDbHelper;
    SQLiteDatabase sqLiteDatabase;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_checking);
        overlayCardView = findViewById(R.id.overlay_card_view);
        usagestats_card_view = findViewById(R.id.usagestats_card_view);
        appInfoDbHelper = new AppInfoDbHelper(getApplicationContext());
        sqLiteDatabase = appInfoDbHelper.getWritableDatabase();
        String SQL_QUERY = "SELECT "+ AppInfoDbHelper.HashEntry.COLUME_HASHED +" FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
        cursor = sqLiteDatabase.rawQuery(SQL_QUERY, null);
        if (GlobalClass.isOverLayGranted(getApplicationContext())){
            overlayCardView.setVisibility(View.GONE);
        }
        if (GlobalClass.isUsageAccessGranted(getApplicationContext(), getPackageManager())){
            usagestats_card_view.setVisibility(View.GONE);
        }
        overlayCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(GlobalClass.isOverLayGranted(getApplicationContext()))){
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                        startActivity(intent);
                    }
                }
            }
        });

        usagestats_card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(GlobalClass.isUsageAccessGranted(getApplicationContext(), getPackageManager()))){
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                        startActivity(intent);
                    }
                }
            }
        });

        if (GlobalClass.isRequiredPermissionGranted(getApplicationContext(), getPackageManager())){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        if (GlobalClass.isOverLayGranted(getApplicationContext())){
            overlayCardView.setVisibility(View.GONE);
        }
        if (GlobalClass.isUsageAccessGranted(getApplicationContext(), getPackageManager())){
            usagestats_card_view.setVisibility(View.GONE);
        }

        if (GlobalClass.isRequiredPermissionGranted(getApplicationContext(), getPackageManager())){
            if (cursor.getCount() > 0){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }else{
                Intent intent = new Intent(getApplicationContext(), PatternLockChoosingActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }
}