package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PinAuthenticationActivity extends AppCompatActivity {
    TextView textView;
    String openedAppPackageName;
    EditText editText;
    AppInfoDbHelper appInfoDbHelper;
    SQLiteDatabase sqLiteDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_authentication);

        //Vairables Initialization
        editText = findViewById(R.id.pinVerify);
        textView = findViewById(R.id.appNameTextView);
        Intent intent = getIntent();
        openedAppPackageName = intent.getStringExtra("openedApp");
        ApplicationInfo applicationInfo = null;
        String appLabel = "";
        appInfoDbHelper = new AppInfoDbHelper(getBaseContext());
        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();

        PackageManager packageManager = getPackageManager();
        try {
            applicationInfo = packageManager.getApplicationInfo(openedAppPackageName, PackageManager.GET_META_DATA);
            appLabel = applicationInfo.loadLabel(packageManager).toString();


        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
//        textView.setText(appLabel+"  is Locked, Please Enter your password to continue");

    }

    public void doUnlockApp(View view) {
        String regularText = editText.getText().toString();
        String encryptedText = PinLockChoosingActivity.encryptText(regularText);

        String encryptedPasswordFromDb = "";

        String SQL_GET_HASHED_PASSWORD = "SELECT "+ AppInfoDbHelper.HashEntry.COLUME_HASHED+" FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(SQL_GET_HASHED_PASSWORD, null);
        if (cursor.getCount() > 0){
            cursor.moveToNext();
            encryptedPasswordFromDb = cursor.getString(0);

            if (encryptedPasswordFromDb.equals(encryptedText)){
                ForegroundService.unlockedApp = openedAppPackageName;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    finishAndRemoveTask();
                }else{
                    finish();
                }
            }else{
                Toast.makeText(this, "Wrong password detected", Toast.LENGTH_SHORT).show();
                editText.setText("");
            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(startMain);
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    public void figureClicked(View view) {
        Button button = (Button) view;
        int clickedNumber = Integer.parseInt(button.getText().toString());
        editText.setText(editText.getText().toString() + clickedNumber);
    }

    public void allClear(View view) {
        editText.setText("");
    }

//    public void clearChar(View view) {
//        String text = String.valueOf(editText.getText());
//        text.
//    }
}