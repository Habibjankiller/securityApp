package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.strictmode.SqliteObjectLeakedViolation;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PinLockChoosingActivity extends AppCompatActivity {
    private EditText pinEditText;
    private AppInfoDbHelper appInfoDbHelper;
    private SQLiteDatabase sqLiteDatabase;
    private static String ALGO = "MD5";
    private TextView textView;
    private boolean isFirst = true;
    private String tryFirst = "";
    private String trySecond = "";
    SharedPreferences sharedPreferences;
    private boolean passwordAlreadySetted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_choosing);
        pinEditText = findViewById(R.id.pinField);
        appInfoDbHelper = new AppInfoDbHelper(this);
        sqLiteDatabase = appInfoDbHelper.getWritableDatabase();
        textView = findViewById(R.id.dialog_pin_text_view);
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        String SQL_QUERY = "SELECT * FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(SQL_QUERY, null);

        if (!(cursor.getCount() > 0)){
            passwordAlreadySetted = false;
        }else{
            passwordAlreadySetted = true;
        }

    }

    public void figureClicked(View view) {
        Button button = (Button) view;
        int clickedNumber = Integer.parseInt(button.getText().toString());
        pinEditText.setText(pinEditText.getText().toString() + clickedNumber);
    }

    public void allClear(View view) {
        pinEditText.setText("");
    }

    public void setPassword(View view) {
        if (pinEditText.getText().toString().length() >= 4){
            if (isFirst){
                String encryptedText = encryptText(pinEditText.getText().toString());
                tryFirst = encryptedText;
                pinEditText.setText("");
                textView.setText("Retype Your Pin");
                isFirst = false;
            }else{
                String encryptedText = encryptText(pinEditText.getText().toString());
                trySecond = encryptedText;
                if (tryFirst.equals(trySecond)){
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(AppInfoDbHelper.HashEntry.COLUMN_HASH_TYPE, ALGO);
                    contentValues.put(AppInfoDbHelper.HashEntry.COLUME_HASHED, encryptedText);
                    if (!passwordAlreadySetted){
                        sqLiteDatabase.insert(AppInfoDbHelper.HashEntry.TABLE_NAME, null, contentValues);
                        Intent intent = new Intent(this, MainActivity.class);
                        startActivity(intent);
                    }else{
                        sqLiteDatabase.update(AppInfoDbHelper.HashEntry.TABLE_NAME, contentValues, AppInfoDbHelper.HashEntry.COLUMN_HASH_TYPE +" = ?", new String[]{ALGO});
                    }
                    sharedPreferences.edit().putString("lock_type", "pin").apply();
                    ForegroundService.lock_type = "pin";
                    finish();
                }else{
                    isFirst = true;
                    textView.setText("Choose your pin");
                }
            }
        }else{
            Toast.makeText(this, "Please Enter At least four Digits", Toast.LENGTH_SHORT).show();
            pinEditText.setText("");
        }
    }

    public static String encryptText (String message){
        MessageDigest passEncrypytor;
        passEncrypytor = null;
        try {
            passEncrypytor = MessageDigest.getInstance(ALGO);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        passEncrypytor.update(message.getBytes());
        byte[] digest = passEncrypytor.digest();
        StringBuffer hexString = new StringBuffer();
        for (int i=0; i<digest.length; i++)
            hexString.append(Integer.toHexString(0xFF & digest[i]));
        Log.d("encryption", hexString.toString());

        return hexString.toString();
    }

    public void clearAll(View view) {
        pinEditText.setText("");
    }
}