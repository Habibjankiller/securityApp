package com.example.secureapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.Notification;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.util.ArrayList;
import java.util.logging.Handler;

public class RecyclerViewAdaptor extends RecyclerView.Adapter<RecyclerViewAdaptor.ViewHolder> {
    ArrayList<ApplicationInfo> applicationInfos;
    PackageManager packageManager;
    Context context;
    SQLiteDatabase sqLiteDatabase;
    public RecyclerViewAdaptor(
            Context context,
            ArrayList<ApplicationInfo> applicationInfos,
            PackageManager packageManager,
            SQLiteDatabase sqLiteDatabase) {
        this.context = context;
        this.applicationInfos = applicationInfos;
        this.packageManager = packageManager;
        this.sqLiteDatabase = sqLiteDatabase;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.app_list_item_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApplicationInfo applicationInfo = applicationInfos.get(position);
        String appName = (String) packageManager.getApplicationLabel(applicationInfo);
        String packageName = applicationInfo.packageName;
        Drawable appIcon = applicationInfo.loadIcon(packageManager);
        Glide.with(context.getApplicationContext()).load(appIcon).into(holder.appIcon);
        holder.app_name.setText(appName);
        final boolean[] appIsLocked = {false};
        ImageView statusSwitch = holder.statusSwitch;
        Resources resources = context.getResources();
        Drawable lockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.locked_toggle, null);
        Drawable unlockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.unlock_toggle, null);
        if (isLocked(appName, packageName)){
            holder.statusSwitch.setImageDrawable(lockDrawable);
            appIsLocked[0] = true;
        }else{
            appIsLocked[0] = false;
            holder.statusSwitch.setImageDrawable(unlockDrawable);
        }


        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                if (!isUsageAccessGranted()){
                    AlertDialog alertDialog = new AlertDialog.Builder(context)
                            .setTitle("Permission Needed")
                            .setMessage("In the Beginning of Android 5.0 You must access to Android Usage Access Permission in order to make your app secure")
                            .setPositiveButton("Grant Permission", new DialogInterface.OnClickListener() {
                                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                                    context.startActivity(intent);
                                }
                            })
                            .setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(context, "Dismiss", Toast.LENGTH_SHORT).show();
                                }
                            }).create();
                    alertDialog.show();

                }else{
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (isOverLayGranted()){
                            if (appIsLocked[0]){
                                Toast.makeText(context, appName + "is Already Locked and making it unlocked", Toast.LENGTH_SHORT).show();
                                try {
                                    int result = deleteAppFromDatabase(packageName);
                                    if (result > 0){
//                            Toast.makeText(context, result+" number of shows were effected", Toast.LENGTH_SHORT).show();
                                        appIsLocked[0] = false;
                                        holder.statusSwitch.setImageDrawable(unlockDrawable);
                                    }
                                } catch (PackageManager.NameNotFoundException e) {
                                    e.printStackTrace();
                                }
                            }else{
                                try {
                                    if (insertAppToDatabase(packageName, sqLiteDatabase)){
                                        holder.statusSwitch.setImageDrawable(lockDrawable);
                                        appIsLocked[0] = true;
                                        Toast.makeText(context, appName +": is Locked", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (PackageManager.NameNotFoundException e) {
                                    e.printStackTrace();
                                }
                            }
                        }else{
                            AlertDialog alertDialog = new AlertDialog.Builder(context)
                                    .setTitle("NEED PERMISSION!")
                                    .setMessage("Draw over other apps permission is needed to activate advance Secure Mode")
                                    .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                                            context.startActivity(intent);
                                        }
                                    })
                                    .create();
                            alertDialog.show();
                        }
                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return applicationInfos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout relativeLayout;
        ImageView appIcon;
        TextView app_name;
        ImageView statusSwitch;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            relativeLayout = itemView.findViewById(R.id.relative_layout);
            appIcon = itemView.findViewById(R.id.app_icon);
            app_name = itemView.findViewById(R.id.app_name);
            statusSwitch = itemView.findViewById(R.id.lock_switch);
        }
    }

    public boolean insertAppToDatabase (String appPackageName, SQLiteDatabase sqLiteDatabase) throws PackageManager.NameNotFoundException {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(appPackageName, PackageManager.GET_META_DATA);
        String appName = applicationInfo.loadLabel(packageManager).toString();
        ContentValues contentValues = new ContentValues();
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_APP_NAME, appName);
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME, appPackageName);
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_ISLOCKED, "true");
        sqLiteDatabase.insert(AppInfoDbHelper.AppEntry.TABLE_NAME, null, contentValues);
        return true;
    }

    public int deleteAppFromDatabase (String appPackageName) throws PackageManager.NameNotFoundException {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(appPackageName, PackageManager.GET_META_DATA);
        String appName = applicationInfo.loadLabel(packageManager).toString();

        int deleteQuery = sqLiteDatabase.delete(
                AppInfoDbHelper.AppEntry.TABLE_NAME,
                AppInfoDbHelper.AppEntry.COLUMN_APP_NAME +" = ? AND "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME +" = ?",
                new String[] {appName, appPackageName});

        return deleteQuery;
    }
    public boolean isLocked (String appName, String packageName){
        Cursor appSearchResult = sqLiteDatabase.rawQuery(
                "SELECT ? FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME +" " +
                        "WHERE "+ AppInfoDbHelper.AppEntry.COLUMN_APP_NAME+" = ? AND "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME + " = ?",
                new String[] {AppInfoDbHelper.AppEntry.COLUMN_ISLOCKED, appName, packageName});
        if (appSearchResult.moveToNext()){
            return true;
        }else{
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public boolean isUsageAccessGranted() {
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.KITKAT) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public boolean isOverLayGranted () {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(context)){
                return true;
            }
        }else{
            return false;
        }
        return false;
    }

}
