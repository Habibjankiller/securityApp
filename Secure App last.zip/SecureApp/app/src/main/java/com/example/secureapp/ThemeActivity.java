package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.tabs.TabLayout;

public class ThemeActivity extends AppCompatActivity {
    WallpaperViewPagerAdaptor wallpaperViewPagerAdaptor;
    ViewPager wallpaperViewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);
        wallpaperViewPagerAdaptor = new WallpaperViewPagerAdaptor(getSupportFragmentManager());
        wallpaperViewPager = findViewById(R.id.wallpaperViewPager);
        wallpaperViewPager.setAdapter(wallpaperViewPagerAdaptor);
        tabLayout = findViewById(R.id.wallpaper_tab_layout);
        tabLayout.setupWithViewPager(wallpaperViewPager);
    }

    public void backIntent(View view) {
        finish();
    }
}