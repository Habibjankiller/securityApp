package com.example.secureapp;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;

public class WallpaperFirebaseRecyclerView extends RecyclerView.Adapter<WallpaperFirebaseRecyclerView.ViewHolder> {
    ArrayList<HashMap<String, String>>  wallpaperList;
    Fragment fragment;
    FirebaseStorage firebaseStorage;
    public WallpaperFirebaseRecyclerView (
            Fragment fragment,
            ArrayList<HashMap<String, String>> wallpaperList) {
        this.wallpaperList = wallpaperList;
        this.fragment = fragment;
        firebaseStorage = FirebaseStorage.getInstance();

    }
    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(fragment.getContext());
        View view = layoutInflater.inflate(R.layout.wallpaper_card_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(WallpaperFirebaseRecyclerView.ViewHolder holder, int position) {
        String gsWallpaperLocation = wallpaperList.get(position).get("wallpaper_location");
        final String[] wallpaperHttpsLocation = {""};
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(gsWallpaperLocation);
        storageReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(Task<Uri> task) {
                if (task.isSuccessful()){
                    wallpaperHttpsLocation[0] = task.getResult().toString();
                    Glide.with(fragment).load(wallpaperHttpsLocation[0]).into(holder.imageView);
                }else{
                    Log.d("glideTask", "Failure Occurs");
                }
            }
        });
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(fragment.getContext(), WallpaperShownActivity.class);
                intent.putExtra("wallpaper_location", wallpaperHttpsLocation[0]);
                intent.putExtra("wallpaper_gs_location", gsWallpaperLocation);
                fragment.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return wallpaperList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.wallpaper_card_image_view);
        }
    }
}
