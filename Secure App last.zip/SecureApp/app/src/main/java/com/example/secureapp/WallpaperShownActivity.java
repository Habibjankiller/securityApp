package com.example.secureapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class WallpaperShownActivity extends AppCompatActivity {
    ImageView fullImageView;
    FirebaseStorage firebaseStorage;
    StorageReference storageReference;
    String imagesDirectoryLocation;
    @SuppressLint("CheckResult")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpaper_shown);
        fullImageView = findViewById(R.id.full_image_view);
        String wallpaperLocation = getIntent().getExtras().getString("wallpaper_location");
        String wallpaperGsLocation = getIntent().getExtras().getString("wallpaper_gs_location");
        Glide.with(this).load(wallpaperLocation).centerCrop().into(fullImageView);
        firebaseStorage = FirebaseStorage.getInstance();
        imagesDirectoryLocation = getFilesDir().getPath();
        storageReference =  firebaseStorage.getReferenceFromUrl(wallpaperGsLocation);
    }

    public void finishActivity(View view) {
        finish();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void setWallpaper(View view) {
        try {
            File imageDirectory = new File(imagesDirectoryLocation);
            if (!imageDirectory.exists()){
                imageDirectory.mkdir();
            }
            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setCancelable(false);
            progressDialog.setTitle("Downloading Image to temp File");
            progressDialog.setMax(100);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.show();
            File imageFile = new File(imageDirectory.getPath(), storageReference.getName());
            if (!imageFile.exists()){
                imageFile.createNewFile();
                Log.d("downloaded", getApplicationContext().getCacheDir().getPath());
                storageReference.getFile(imageFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                        Toast.makeText(WallpaperShownActivity.this, "File downloaded successfully", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            SharedPreferences sharedPreferences = getSharedPreferences(
                                    getResources().getString(R.string.myAppSharedPreferences),
                                    Context.MODE_PRIVATE);
                            sharedPreferences.edit().putString("currentWallpaperLocation", imageFile.getPath()).apply();

                        }

                    }
                })
                        .addOnProgressListener(new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(FileDownloadTask.TaskSnapshot snapshot) {
                                String downloadedPercentage = String.valueOf(snapshot.getBytesTransferred() * 100 /snapshot.getTotalByteCount());
                                progressDialog.setProgress(Integer.parseInt(downloadedPercentage));


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure( Exception e) {
                                Toast.makeText(WallpaperShownActivity.this, "Error Occurs while Downloading a file", Toast.LENGTH_SHORT).show();
                            }
                        });
            }else{
                progressDialog.dismiss();
                Toast.makeText(this, "File already exist", Toast.LENGTH_SHORT).show();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}