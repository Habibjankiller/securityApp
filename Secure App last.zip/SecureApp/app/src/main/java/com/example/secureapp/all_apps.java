package com.example.secureapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link all_apps#newInstance} factory method to
 * create an instance of this fragment.
 */
public class all_apps extends Fragment {
    private PackageManager packageManager;
    LayoutInflater layoutInflater;
    LinearLayout allAppsLinearLayout;
    LinearLayout importantAppsLinearLayout;
    Handler uiHandler;
    private SharedPreferences sharedPreferences;

    //RecyclerView Variables
    RecyclerView recyclerView;


    //ViewModel
    LockAppsViewModel lockAppsViewModel;
    LiveData<List<LockApp>> lockedAppsList;
    Observer<List<LockApp>> liveDataObserver;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public all_apps() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment all_apps.
     */
    // TODO: Rename and change types and number of parameters
    public static all_apps newInstance(String param1, String param2) {
        all_apps fragment = new all_apps();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @SuppressLint("NewApi")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_all_apps, container, false);
        //Variables Initilization
        importantAppsLinearLayout = view.findViewById(R.id.important_app_list);
        uiHandler = new Handler();
        layoutInflater = getLayoutInflater();
        packageManager = getContext().getPackageManager();

        //ViewModel and LiveData
        lockAppsViewModel = new LockAppsViewModel(getActivity().getApplication());

        allAppsLinearLayout = view.findViewById(R.id.all_apps_linear_layout);
        sharedPreferences = getActivity().getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);

        liveDataObserver = new Observer<List<LockApp>>() {
            @Override
            public void onChanged(List<LockApp> lockApps) {
                for (int i = 0; i < allAppsLinearLayout.getChildCount(); i++) {
                    View appView = allAppsLinearLayout.getChildAt(i);
                    TextView appNameTextView = appView.findViewById(R.id.app_name);
                    ImageView statusSwitch = appView.findViewById(R.id.lock_type_status);
                    String appName = appNameTextView.getText().toString();

                    if (lockApps.get(i).appName.equals(appName)){
                        statusSwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));
                    }else{
                        statusSwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
                    }
                }
            }
        };

        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<ApplicationInfo> allApps = GlobalClass.getAllApps(packageManager);
                for(ApplicationInfo applicationInfo: allApps){
                    uiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            View appView = layoutInflater.inflate(R.layout.app_list_item_design, allAppsLinearLayout, false);
                            ImageView iconImageView = appView.findViewById(R.id.app_icon);
                            TextView appName = appView.findViewById(R.id.app_name);
                            RelativeLayout appViewLayout = appView.findViewById(R.id.relative_layout);
                            appName.setText(applicationInfo.loadLabel(packageManager));
                            iconImageView.setImageDrawable(applicationInfo.loadIcon(packageManager));
                            appViewLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    LockApp lockApp = new LockApp(applicationInfo.loadLabel(packageManager).toString(), applicationInfo.packageName);
                                    lockAppsViewModel.insertApp(lockApp);
                                }
                            });
                            allAppsLinearLayout.addView(appView);
//                            lockedAppsList = lockAppsViewModel.getLockAppsList();
//                            lockedAppsList.observe(getViewLifecycleOwner(), liveDataObserver);
                        }
                    });
                }
            }
        }).start();



        return view;
    }
}