package com.example.secureapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link all_apps#newInstance} factory method to
 * create an instance of this fragment.
 */
public class all_apps extends Fragment {
    private RecyclerView recyclerView;
    private RecyclerViewAdaptor recyclerViewAdaptor;
    private ArrayList<ApplicationInfo> filteredApplicationInfo;
    private PackageManager packageManager;
    private ArrayList<ApplicationInfo> allApplicationInfos;
    private ArrayList<ApplicationInfo> socialAppInfoes;
    private ArrayList<String> socialAppsList = new ArrayList<>();
    private ArrayList<String> importantAppList = new ArrayList<>();
    private SQLiteDatabase sqLiteDatabase;
    private AppInfoDbHelper appInfoDbHelper;
    LayoutInflater layoutInflater;
    LinearLayout socialAppsLayout;
    LinearLayout allAppsLinearLayout;
    LinearLayout importantAppsLinearLayout;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public all_apps() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment all_apps.
     */
    // TODO: Rename and change types and number of parameters
    public static all_apps newInstance(String param1, String param2) {
        all_apps fragment = new all_apps();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        socialAppsList.add("com.facebook.katana");
        socialAppsList.add("com.whatsapp");

        importantAppList.add("com.android.settings");


    }

    @SuppressLint("NewApi")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_all_apps, container, false);

        //Variables Initilization
        socialAppsLayout = view.findViewById(R.id.social_app_list);
        allAppsLinearLayout = view.findViewById(R.id.all_apps_linear_layout);
        importantAppsLinearLayout = view.findViewById(R.id.important_app_list);

        layoutInflater = getLayoutInflater();
        filteredApplicationInfo = new ArrayList<>();
        packageManager = getContext().getPackageManager();
        appInfoDbHelper = new AppInfoDbHelper(getContext());
        sqLiteDatabase = appInfoDbHelper.getWritableDatabase();

        allApplicationInfos = (ArrayList<ApplicationInfo>) packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
        socialAppInfoes = new ArrayList<>();
        for (ApplicationInfo applicationInfo: allApplicationInfos){
            if (applicationInfo.category == ApplicationInfo.CATEGORY_SOCIAL){
                socialAppInfoes.add(applicationInfo);
            }
        }
        for (ApplicationInfo applicationInfo: allApplicationInfos){
            //Getting only filter application (Applications with Launcher Intent);
            if (packageManager.getLaunchIntentForPackage(applicationInfo.packageName) != null){
                filteredApplicationInfo.add(applicationInfo);
            }
        }

        if (Build.VERSION.SDK_INT >= 24){
            filteredApplicationInfo.sort(new Comparator<ApplicationInfo>() {
                @Override
                public int compare(ApplicationInfo o1, ApplicationInfo o2) {
                    String firstAppName = o1.loadLabel(packageManager).toString();
                    String secondAppName = o2.loadLabel(packageManager).toString();
                    return String.CASE_INSENSITIVE_ORDER.compare(firstAppName, secondAppName);
                }
            });
        }else{
            Collections.sort(filteredApplicationInfo, new Comparator<ApplicationInfo>() {
                @Override
                public int compare(ApplicationInfo o1, ApplicationInfo o2) {
                    String firstAppName = o1.loadLabel(packageManager).toString();
                    String secondAppName = o2.loadLabel(packageManager).toString();
                    return String.CASE_INSENSITIVE_ORDER.compare(firstAppName, secondAppName);
                }
            });
        }
        setImportantApps(socialAppsList, socialAppsLayout);
        setImportantApps(importantAppList, importantAppsLinearLayout);
        setImportantApps(allAppsLinearLayout);

        return view;
    }

    public boolean insertAppToDatabase (String appPackageName, SQLiteDatabase sqLiteDatabase) throws PackageManager.NameNotFoundException {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(appPackageName, PackageManager.GET_META_DATA);
        String appName = applicationInfo.loadLabel(packageManager).toString();
        ContentValues contentValues = new ContentValues();
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_APP_NAME, appName);
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME, appPackageName);
        contentValues.put(AppInfoDbHelper.AppEntry.COLUMN_ISLOCKED, "true");
        sqLiteDatabase.insert(AppInfoDbHelper.AppEntry.TABLE_NAME, null, contentValues);
        return true;
    }

    public int deleteAppFromDatabase (String appPackageName) throws PackageManager.NameNotFoundException {
        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(appPackageName, PackageManager.GET_META_DATA);
        String appName = applicationInfo.loadLabel(packageManager).toString();

        int deleteQuery = sqLiteDatabase.delete(
                AppInfoDbHelper.AppEntry.TABLE_NAME,
                AppInfoDbHelper.AppEntry.COLUMN_APP_NAME +" = ? AND "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME +" = ?",
                new String[] {appName, appPackageName});

        return deleteQuery;
    }
    public boolean isLocked (String appName, String packageName){
        Cursor appSearchResult = sqLiteDatabase.rawQuery(
                "SELECT ? FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME +" " +
                        "WHERE "+ AppInfoDbHelper.AppEntry.COLUMN_APP_NAME+" = ? AND "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME + " = ?",
                new String[] {AppInfoDbHelper.AppEntry.COLUMN_ISLOCKED, appName, packageName});
        if (appSearchResult.moveToNext()){
            return true;
        }else{
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public boolean isUsageAccessGranted() {
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(getContext().getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) getContext().getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.KITKAT) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public boolean isOverLayGranted () {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(getContext())){
                return true;
            }
        }else{
            return false;
        }
        return false;
    }

    private void setImportantApps (ArrayList<String> importantAppList, ViewGroup viewGroup){
        for (ApplicationInfo filteredApps: filteredApplicationInfo){
            if (importantAppList.contains(filteredApps.packageName)){
                //Layout Views
                View appView = layoutInflater.inflate(R.layout.app_list_item_design, viewGroup, false);
                TextView textView = appView.findViewById(R.id.app_name);
                ImageView appIcon = appView.findViewById(R.id.app_icon);
                ImageView statusSwitch = appView.findViewById(R.id.lock_switch);
                RelativeLayout relativeLayout = appView.findViewById(R.id.relative_layout);
                //Application MEta Data
                Drawable drawable = null;
                String appName = (String) filteredApps.loadLabel(packageManager);
                final boolean[] appIsLocked = {false};
                String packageName = filteredApps.packageName;

                try {
                    drawable = packageManager.getApplicationIcon(filteredApps.packageName);
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }

                textView.setText(filteredApps.loadLabel(packageManager));
                appIcon.setImageDrawable(drawable);


                Resources resources = getContext().getResources();
                Drawable lockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.locked_toggle, null);
                Drawable unlockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.unlock_toggle, null);
                if (isLocked(appName, packageName)){
                    statusSwitch.setImageDrawable(lockDrawable);
                    appIsLocked[0] = true;
                }else{
                    appIsLocked[0] = false;
                    statusSwitch.setImageDrawable(unlockDrawable);
                }


                relativeLayout.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onClick(View v) {
                        if (!isUsageAccessGranted()){
                            AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                                    .setTitle("Permission Needed")
                                    .setMessage("In the Beginning of Android 5.0 You must access to Android Usage Access Permission in order to make your app secure")
                                    .setPositiveButton("Grant Permission", new DialogInterface.OnClickListener() {
                                        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                                            getContext().startActivity(intent);
                                        }
                                    })
                                    .setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Toast.makeText(getContext(), "Dismiss", Toast.LENGTH_SHORT).show();
                                        }
                                    }).create();
                            alertDialog.show();

                        }else{
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                if (isOverLayGranted()){
                                    if (appIsLocked[0]){
                                        Toast.makeText(getContext(), appName + "is Already Locked and making it unlocked", Toast.LENGTH_SHORT).show();
                                        try {
                                            int result = deleteAppFromDatabase(packageName);
                                            if (result > 0){
//                            Toast.makeText(context, result+" number of shows were effected", Toast.LENGTH_SHORT).show();
                                                appIsLocked[0] = false;
                                                statusSwitch.setImageDrawable(unlockDrawable);
                                            }
                                        } catch (PackageManager.NameNotFoundException e) {
                                            e.printStackTrace();
                                        }
                                    }else{
                                        try {
                                            if (insertAppToDatabase(packageName, sqLiteDatabase)){
                                                statusSwitch.setImageDrawable(lockDrawable);
                                                appIsLocked[0] = true;
                                                Toast.makeText(getContext(), appName +": is Locked", Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (PackageManager.NameNotFoundException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }else{
                                    AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                                            .setTitle("NEED PERMISSION!")
                                            .setMessage("Draw over other apps permission is needed to activate advance Secure Mode")
                                            .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                                                    getContext().startActivity(intent);
                                                }
                                            })
                                            .create();
                                    alertDialog.show();
                                }
                            }
                        }
                    }
                });

                viewGroup.addView(appView);
            }
        }


    }

    private void setImportantApps (ViewGroup viewGroup){
        for (ApplicationInfo filteredApps: filteredApplicationInfo){
            //Layout Views
            View appView = layoutInflater.inflate(R.layout.app_list_item_design, viewGroup, false);
            TextView textView = appView.findViewById(R.id.app_name);
            ImageView appIcon = appView.findViewById(R.id.app_icon);
            ImageView statusSwitch = appView.findViewById(R.id.lock_switch);
            RelativeLayout relativeLayout = appView.findViewById(R.id.relative_layout);
            //Application MEta Data
            Drawable drawable = null;
            String appName = (String) filteredApps.loadLabel(packageManager);
            final boolean[] appIsLocked = {false};
            String packageName = filteredApps.packageName;

            try {
                drawable = packageManager.getApplicationIcon(filteredApps.packageName);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

            textView.setText(filteredApps.loadLabel(packageManager));
            appIcon.setImageDrawable(drawable);


            Resources resources = getContext().getResources();
            Drawable lockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.locked_toggle, null);
            Drawable unlockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.unlock_toggle, null);
            if (isLocked(appName, packageName)){
                statusSwitch.setImageDrawable(lockDrawable);
                appIsLocked[0] = true;
            }else{
                appIsLocked[0] = false;
                statusSwitch.setImageDrawable(unlockDrawable);
            }


            relativeLayout.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onClick(View v) {
                    if (!isUsageAccessGranted()){
                        AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                                .setTitle("Permission Needed")
                                .setMessage("In the Beginning of Android 5.0 You must access to Android Usage Access Permission in order to make your app secure")
                                .setPositiveButton("Grant Permission", new DialogInterface.OnClickListener() {
                                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                                        getContext().startActivity(intent);
                                    }
                                })
                                .setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(getContext(), "Dismiss", Toast.LENGTH_SHORT).show();
                                    }
                                }).create();
                        alertDialog.show();

                    }else{
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (isOverLayGranted()){
                                if (appIsLocked[0]){
                                    Toast.makeText(getContext(), appName + "is Already Locked and making it unlocked", Toast.LENGTH_SHORT).show();
                                    try {
                                        int result = deleteAppFromDatabase(packageName);
                                        if (result > 0){
//                            Toast.makeText(context, result+" number of shows were effected", Toast.LENGTH_SHORT).show();
                                            appIsLocked[0] = false;
                                            statusSwitch.setImageDrawable(unlockDrawable);
                                        }
                                    } catch (PackageManager.NameNotFoundException e) {
                                        e.printStackTrace();
                                    }
                                }else{
                                    try {
                                        if (insertAppToDatabase(packageName, sqLiteDatabase)){
                                            statusSwitch.setImageDrawable(lockDrawable);
                                            appIsLocked[0] = true;
                                            Toast.makeText(getContext(), appName +": is Locked", Toast.LENGTH_SHORT).show();
                                        }
                                    } catch (PackageManager.NameNotFoundException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }else{
                                AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                                        .setTitle("NEED PERMISSION!")
                                        .setMessage("Draw over other apps permission is needed to activate advance Secure Mode")
                                        .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                                                getContext().startActivity(intent);
                                            }
                                        })
                                        .create();
                                alertDialog.show();
                            }
                        }
                    }
                }
            });

            viewGroup.addView(appView);
        }
    }
}