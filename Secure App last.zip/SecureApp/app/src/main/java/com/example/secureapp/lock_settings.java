package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

public class lock_settings extends AppCompatActivity {
    NoScrollingViewPager noScrollingViewPager;
    UnlockSettingViewPagerAdaptor unlockSettingViewPagerAdaptor;
    LinearLayout pinLinearLayoutButton;
    LinearLayout patternLinearLayoutButton;
    SharedPreferences sharedPreferences;
    private String unlockMethod;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_settings);
        noScrollingViewPager = findViewById(R.id.unlock_setting_view_pager);
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        pinLinearLayoutButton = findViewById(R.id.pin_layout_button);
        patternLinearLayoutButton = findViewById(R.id.pattern_layout_button);
        unlockMethod = sharedPreferences.getString("lock_type", "none");
        if (unlockMethod.equals("pin")){
            pinLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
            patternLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryLight));
            noScrollingViewPager.setCurrentItem(0, false);
            pinLinearLayoutButton.setEnabled(false);
        }else if (unlockMethod.equals("pattern")){
            pinLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryLight));
            patternLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
            noScrollingViewPager.setCurrentItem(1, false);
            patternLinearLayoutButton.setEnabled(false);
        }
        noScrollingViewPager.setPagingEnabled(false);
        unlockSettingViewPagerAdaptor = new UnlockSettingViewPagerAdaptor(getSupportFragmentManager());
        noScrollingViewPager.setAdapter(unlockSettingViewPagerAdaptor);
        pinLinearLayoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(lock_settings.this, PinLockChoosingActivity.class);
                startActivity(intent);
            }
        });
        patternLinearLayoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(lock_settings.this, PatternLockChoosingActivity.class);
                startActivity(intent);
            }
        });


    }

    public void finishActivity(View view) {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        unlockMethod = sharedPreferences.getString("lock_type", "none");
        if (unlockMethod.equals("pin")){
            pinLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
            patternLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryLight));
            pinLinearLayoutButton.setEnabled(false);
            patternLinearLayoutButton.setEnabled(true);
            noScrollingViewPager.setCurrentItem(0, false);
        }else if (unlockMethod.equals("pattern")){
            pinLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryLight));
            patternLinearLayoutButton.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
            patternLinearLayoutButton.setEnabled(false);
            pinLinearLayoutButton.setEnabled(true);
            noScrollingViewPager.setCurrentItem(1, false);
        }
    }
}