package com.example.secureapp;

import android.content.Context;
import android.os.Handler;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.locks.Lock;

public class AppRepository {
    private LockedAppsDao lockedAppsDao;
    private LiveData<List<LockApp>> allLockApps;
    public AppRepository(Context context) {
        LockedAppsDatabase lockedAppsDatabase = LockedAppsDatabase.getInstance(context);
        lockedAppsDao = lockedAppsDatabase.lockAppsDao();
        allLockApps = lockedAppsDao.getAllLockedApps();
    }

    void insertAppToDatabase (LockApp appToInsert) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                LockApp lockApp = getAppFromDatabase(appToInsert.appPackageName);
                if (lockApp == null){
                    lockedAppsDao.insertApps(appToInsert);
                }
            }
        }).start();
    }

    void deleteAppFromDatabase (String appPackageName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                LockApp lockApp = getAppFromDatabase(appPackageName);
                if (lockApp != null){
                    lockedAppsDao.deleteLockApp(lockApp);
                }
            }
        }).start();
    }

    void deleteAllApps() {
        lockedAppsDao.deleteAllApps();
    }

    List<LockApp> getAllApps () {
        return lockedAppsDao.getAllApps();
    }

    public LockApp getAppFromDatabase (String appPackageName) {
        return lockedAppsDao.getLockAppByPackageName(appPackageName);
    }

    public LiveData<List<LockApp>> getAllLockApps () {
        return allLockApps;
    }


}
