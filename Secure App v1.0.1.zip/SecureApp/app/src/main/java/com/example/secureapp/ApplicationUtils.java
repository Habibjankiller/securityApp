package com.example.secureapp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.google.common.util.concurrent.ListenableFutureTask;

import java.util.ArrayList;
import java.util.List;

public class ApplicationUtils {

    //return constructor
    private static ApplicationUtils applicationUtils;

    //Application Infoes
    private ArrayList<String> unlockedApps;
    private String lastUnlockedApp;
    SharedPreferences sharedPreferences;
    Application application;
    ArrayList<String> lockedAppsPackageList;

    public static ApplicationUtils initialize (Application application) {
        if (applicationUtils == null){
            applicationUtils = new ApplicationUtils(application);
        }
        return applicationUtils;
    }

    //Make the constructor Private
    private ApplicationUtils(Application application) {
        unlockedApps = new ArrayList<>();
        lastUnlockedApp = "";
        this.application = application;
        sharedPreferences = application.getSharedPreferences(application.getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        lockedAppsPackageList = new ArrayList<>();
    }

    //Unlocking App
    void unlockApp (String appPackageName) {
        if (isRelockAfterScreenOn()){
            unlockedApps.add(appPackageName);
        }
        lastUnlockedApp = appPackageName;
    }

    public boolean appToBeLock (String appPackageName) {
        if (lockedAppsPackageList.contains(appPackageName)){
            if (isRelockAfterScreenOn()){
                Log.d("backgroundtask", "relock after screen on is true");
                if (!unlockedApps.contains(appPackageName)){
                    Log.d("backgroundtask", "unlock app does not contains this app");
                    return true;
                }
            }else{
                Log.d("backgroundtask", "Relock After screen on is false");
                if (!lastUnlockedApp.equals(appPackageName)){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isRelockAfterScreenOn() {
        return sharedPreferences.getBoolean(application.getString(R.string.lock_after_screen_on_preferences), false);
    }


    //Setters and getters
    public ArrayList<String> getUnlockedApps() {
        return unlockedApps;
    }

    public void setUnlockedApps(ArrayList<String> unlockedApps) {
        this.unlockedApps = unlockedApps;
    }

    public String getLastUnlockedApp() {
        return lastUnlockedApp;
    }

    public void setLastUnlockedApp(String lastUnlockedApp) {
        this.lastUnlockedApp = lastUnlockedApp;
    }
}
