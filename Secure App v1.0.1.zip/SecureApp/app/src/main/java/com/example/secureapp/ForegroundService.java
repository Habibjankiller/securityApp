package com.example.secureapp;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.AppLaunchChecker;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleService;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;
import com.bumptech.glide.Glide;
import com.chaos.view.PinView;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.ads.nativetemplates.TemplateView;
import com.rvalerio.fgchecker.AppChecker;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ForegroundService extends LifecycleService {

    //Algorithm to be Uses for encryption
    private static final String ALGO = "MD5";

    //ForegroundService Notification
    public static int FOREGROUND_SERVICE_ID = 124;
    public static String FOREGROUND_NOTIFICATION_CHANNEL_ID = "foreground_notification";
    NotificationManager notificationManager;
    NotificationChannel notificationChannel;
    Notification foregroundNotification;
    PendingIntent pendingIntentNotification;
    Intent notificationIntent;

    //Lock type pin || pattter
    public static String lock_type = "";

    //UiHandler
    Handler lockHandler;

    //Timer for many functionalities
    private Timer timer = new Timer();

    //ViewModel + LockApps
    LockAppsViewModel lockAppsViewModel;
    LiveData<List<LockApp>> lockAppsLiveData;
    PasswordsViewModel passwordsViewModel;
    LiveData<List<HashEntity>> listLiveDataHash;

    //Overlay Objects Window Manager
    WindowManager windowManager;
    WindowManager.LayoutParams layoutParams;

    //LockView
    View lockView;

    //Layout Flags
    int LAYOUT_FLAG;

    //FLAGS For Application Query
    private int APPLICATION_OPENED = 0;
    public static String opened_app = "";

    //SharedPreferences and sharedPreferencesChangeListener
    SharedPreferences sharedPreferences;
    SharedPreferences.OnSharedPreferenceChangeListener sharedPreferenceChangeListener;

    //Application Utilities
    ApplicationUtils applicationUtils;
    ArrayList<String> lockedApps;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        super.onBind(intent);
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate() {
        super.onCreate();
        initializeVariables();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        foregroundNotification = new NotificationCompat.Builder(this, FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setContentIntent(pendingIntentNotification)
                .setContentText("Protecting your privacy")
                .setChannelId(FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setOngoing(true)
                .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                .setSmallIcon(R.drawable.logo_design)
                .setContentTitle(getResources().getString(R.string.app_name)).build();
        sharedPreferenceChangeListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override
            public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                if (key.equals(getString(R.string.lock_type))){
                    lock_type = sharedPreferences.getString(key, "pattern");
                    windowManager.removeView(lockView);
                    initializeLockView();
                }
            }
        };
        sharedPreferences.registerOnSharedPreferenceChangeListener(sharedPreferenceChangeListener);
        initializeLockView();


        new Thread(new Runnable() {
            @Override
            public void run() {
                lockAppsLiveData = lockAppsViewModel.getLockAppsList();
                lockedApps = lockAppsViewModel.getLockedAppsPackageName();
                listLiveDataHash = passwordsViewModel.getAllPasswords();
                registerScreenOnBroadcastReceiver();
                lockHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        lockAppsLiveData.observe(ForegroundService.this, new Observer<List<LockApp>>() {
                            @Override
                            public void onChanged(List<LockApp> lockApps) {
                                lockedApps.clear();
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        for (LockApp lockApp : lockApps) {
                                            lockedApps.add(lockApp.appPackageName);
                                        }
                                        applicationUtils.lockedAppsPackageList = lockedApps;
                                        Log.d("backgroundtask", String.valueOf(applicationUtils.lockedAppsPackageList.size()));
                                    }
                                }).start();
                            }
                        });
                    }
                });
            }
        }).start();

        AppChecker appChecker = new AppChecker();
        appChecker.whenAny(new AppChecker.Listener() {
            @Override
            public void onForeground(String process) {
                if (opened_app == null){
                    opened_app = "";
                }
                if (process != null){
                    if (!(opened_app.equals(process)) && !(process.equals(getPackageName()))) {
                        opened_app = process;
                        if (applicationUtils.appToBeLock(opened_app)) {
                            Log.d("backgroundtask", process + "Locked App detected");
                            if (process.equals("com.android.settings")) {
                                Intent lockIntent;
                                lockHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        deactivateLock();
                                    }
                                });
                                if (lock_type.equals("pin")) {
                                    lockIntent = new Intent(getApplicationContext(), PinAuthenticationActivity.class);
                                    //SET ACTIVITY FLAGS
                                    lockIntent.setFlags(
                                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                                                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                                    Intent.FLAG_ACTIVITY_NEW_TASK |
                                                    Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
                                                    Intent.FLAG_FROM_BACKGROUND
                                    );
                                } else {
                                    lockIntent = new Intent(getApplicationContext(), PatternAuthenticationActivity.class);
                                    lockIntent.setFlags(
                                            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                                                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                                    Intent.FLAG_ACTIVITY_NEW_TASK |
                                                    Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
                                                    Intent.FLAG_FROM_BACKGROUND
                                    );
                                }
                                lockIntent.putExtra("openedApp", opened_app);
                                APPLICATION_OPENED = 1;
                                Log.d("backgroundtask", "Starting Auth Activity");
                                startActivity(lockIntent);
                                //RUN LOCK ACTIVITY
                            } else {
                                activateLock();
                            }
                        } else {
                            deactivateLock();
                        }
                    }
                }
            }
        }).timeout(300).start(getApplicationContext());
        startForeground(FOREGROUND_SERVICE_ID, foregroundNotification);
        return START_STICKY;
    }

    private void registerScreenOnBroadcastReceiver() {
        getApplicationContext().registerReceiver(new ScreenOnAndOffBroadcastReceiver(), new IntentFilter(Intent.ACTION_SCREEN_ON));
    }


    private void deactivateLock () {
        lockHandler.post(new Runnable() {
            @Override
            public void run() {
                if (lockView != null){
                    if (lockView.getParent() != null){
                        if (lockView.getVisibility() == View.VISIBLE){
                            lockView.setVisibility(View.GONE);

                            if (lock_type.equals("pin")){
                                lockHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (lockView.getParent() != null){
                                            EditText editText = lockView.findViewById(R.id.pinVerify);
                                            editText.setText("");
                                        }
                                    }
                                });
                            }else{
                                PatternLockView patternLockView = lockView.findViewById(R.id.unlockAppPatternView);
                                patternLockView.clearPattern();
                            }

                        }
                    }
                }
            }
        });
        applicationUtils.setLastUnlockedApp("");
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void activateLock () {
        if (lockView == null){
            addLockView();
            lockView.setVisibility(View.VISIBLE);
        }else{
            if (lockView.getWindowToken() != null){
                lockView.setVisibility(View.VISIBLE);
            }else{
                addLockView();
                lockView.setVisibility(View.VISIBLE);
            }
        }

//        if (lockView != null){
//            Log.d("backgroundtask", "Lock View is not Null");
//            if (lockView.getWindowToken() != null){
//                Log.d("backgroundtask", "Lock View is Visible");
//
//            }else{
//                Log.d("backgroundtask", "Lock View is Visible");
//                addLockView();
//            }
//        }else{
//            addLockView();
//            activateLock();
//        }
        APPLICATION_OPENED = 1;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void addLockView() {
        if (lockView != null){
            if (lockView.getWindowToken() != null){
                lockHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        windowManager.removeView(lockView);
                    }
                });
            }
        }
        initializeLockView();
    }

    private void initializeLockView () {
        if (lock_type.equals("pin")){
            lockView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pin_lock_authentication_overlay, null, false);
            GridLayout gridView = lockView.findViewById(R.id.numbersGridView);

            PinView pinEditText = (PinView) lockView.findViewById(R.id.pinVerify);

            ImageView imageView = lockView.findViewById(R.id.donePin);
            Log.d("backgroundtask", "adding pin overlay");
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String encryptedText = encryptText(pinEditText.getText().toString());
                            HashEntity hashEntity = passwordsViewModel.getHash(encryptedText);
                            if (hashEntity != null){
                                lockHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        deactivateLock();
                                        applicationUtils.unlockApp(opened_app);
                                    }
                                });
                            }else{
                                lockHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        pinEditText.setText("");
                                        YoYo.with(Techniques.Pulse).repeat(3).duration(500).playOn(pinEditText);
                                    }
                                });
                            }
                        }
                    }).start();
                }
            });
            Button clearButton = lockView.findViewById(R.id.clearButton);
            clearButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pinEditText.setText("");
                }
            });
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ArrayList<View> views = getViewsByTag(gridView, "figureButton");
                    for (View view: views){
                        Button button = (Button) view;
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                lockHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        pinEditText.setText(pinEditText.getText().toString() + button.getText().toString());
                                    }
                                });
                            }
                        });
                    }
                }
            }).start();
        }else{
            lockView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pattern_lock_authentication_overlay, null, false);
            SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
            Log.d("backgroundtask", "adding pattern overlay");
            PatternLockView patternLockView = lockView.findViewById(R.id.unlockAppPatternView);
            patternLockView.setDotCount(3);
            patternLockView.setAspectRatioEnabled(true);
            patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
            patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
            patternLockView.setDotAnimationDuration(150);
            patternLockView.setPathEndAnimationDuration(100);
            patternLockView.setInStealthMode(sharedPreferences.getBoolean("pattern_visible", false));
            patternLockView.setTactileFeedbackEnabled(true);
            patternLockView.setInputEnabled(true);
            patternLockView.addPatternLockListener(new PatternLockViewListener() {
                @Override
                public void onStarted() {

                }

                @Override
                public void onProgress(List<PatternLockView.Dot> progressPattern) {

                }

                @Override
                public void onComplete(List<PatternLockView.Dot> pattern) {
                    if (pattern.size() < 4){
                        Toast.makeText(getApplicationContext(), "Draw Four", Toast.LENGTH_SHORT).show();
                        patternLockView.clearPattern();
                    }else{
                        String patternToMD5 = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                HashEntity hashEntity = passwordsViewModel.getHash(patternToMD5);
                                if (hashEntity != null && hashEntity.password_type.equals(lock_type)){
                                    if (hashEntity.password_hash.equals(patternToMD5)){
                                        deactivateLock();
                                        applicationUtils.unlockApp(opened_app);
                                    }
                                }else{
                                    lockHandler.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            patternLockView.clearPattern();
                                            YoYo.with(Techniques.Tada)
                                                    .duration(100)
                                                    .repeat(2)
                                                    .playOn(patternLockView);
                                        }
                                    });
                                }
                            }
                        }).start();
                    }
                }

                @Override
                public void onCleared() {

                }
            });
        }

        lockHandler.post(new Runnable() {
            @Override
            public void run() {
                lockView.setVisibility(View.GONE);
                windowManager.addView(lockView, layoutParams);
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (lockView != null){
            if (lockView.isAttachedToWindow()){
                windowManager.removeView(lockView);
            }
        }

        Intent intent = new Intent(getApplicationContext(), ForegroundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        }else{
            startService(intent);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void initializeVariables () {
        opened_app = "";
        sharedPreferences = getSharedPreferences(getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        lock_type = sharedPreferences.getString(getString(R.string.lock_type), "none");

        windowManager = (WindowManager) getSystemService(Service.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
        }
        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION |
                        WindowManager.LayoutParams.FLAG_DIM_BEHIND |
                        WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
        );

        lockHandler = new Handler();
        notificationIntent = new Intent(this, MainActivity.class);
        pendingIntentNotification = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        lockAppsViewModel = new LockAppsViewModel(getApplication());
        passwordsViewModel = new PasswordsViewModel(getApplication());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationChannel = new NotificationChannel(
                    FOREGROUND_NOTIFICATION_CHANNEL_ID,
                    "Notification Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

        applicationUtils = ApplicationUtils.initialize(getApplication());
    }

    private static ArrayList<View> getViewsByTag(ViewGroup root, String tag){
        ArrayList<View> views = new ArrayList<View>();
        final int childCount = root.getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View child = root.getChildAt(i);
            if (child instanceof ViewGroup) {
                views.addAll(getViewsByTag((ViewGroup) child, tag));
            }

            final Object tagObj = child.getTag();
            if (tagObj != null && tagObj.equals(tag)) {
                views.add(child);
            }

        }
        return views;
    }



    public static String encryptText (String message){
        MessageDigest passEncrypytor;
        passEncrypytor = null;
        try {
            passEncrypytor = MessageDigest.getInstance(ALGO);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        passEncrypytor.update(message.getBytes());
        byte[] digest = passEncrypytor.digest();
        StringBuffer hexString = new StringBuffer();
        for (int i=0; i<digest.length; i++)
            hexString.append(Integer.toHexString(0xFF & digest[i]));
        Log.d("encryption", hexString.toString());

        return hexString.toString();
    }
}
