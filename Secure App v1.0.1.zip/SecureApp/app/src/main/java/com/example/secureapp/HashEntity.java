package com.example.secureapp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "hash_table")
public class HashEntity {

    @PrimaryKey(autoGenerate = true)
    public int hash_id;

    @ColumnInfo(name = "password_type")
    public String password_type;

    @ColumnInfo(name = "password_hash")
    public String password_hash;

    public HashEntity(String password_type, String password_hash) {
        this.password_type = password_type;
        this.password_hash = password_hash;
    }
}
