package com.example.secureapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface HashEntityDao {


    @Insert
    public void insert(HashEntity... hashEntities);

    @Query("SELECT * FROM hash_table")
    public LiveData<List<HashEntity>> getPasswords();

    @Query("DELETE FROM hash_table")
    public void deleteAllPasswords();


    @Query("SELECT * FROM hash_table WHERE password_type LIKE :type")
    public HashEntity getHashByType(String type);

    @Update
    public void updateEntity (HashEntity hashEntity);

    @Query("DELETE FROM hash_table WHERE password_hash LIKE :hash_password")
    public void deleteHash(String hash_password);

    @Query("SELECT * FROM hash_table WHERE password_hash Like :hash")
    public HashEntity getHash(String hash);
}
