package com.example.secureapp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "locked_apps")
public class LockApp {

    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "app_name")
    public String appName;

    @ColumnInfo(name = "app_package_name")
    public String appPackageName;

    public LockApp(String appName, String appPackageName) {
        this.appName = appName;
        this.appPackageName = appPackageName;
    }
}
