package com.example.secureapp;

import android.app.Application;
import android.content.pm.ApplicationInfo;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class LockAppsViewModel extends AndroidViewModel {
    private AppRepository appRepository;
    private LiveData<List<LockApp>> lockAppsList;
    private ApplicationUtils applicationUtils;

    public LockAppsViewModel(@NonNull Application application) {
        super(application);
        appRepository = new AppRepository(application);
        lockAppsList = appRepository.getAllLockApps();
        applicationUtils = ApplicationUtils.initialize(getApplication());
    }

    public void insertApp (LockApp lockApp) {
        if (getAppByPackageName(lockApp.appPackageName) == null){
            appRepository.insertAppToDatabase(lockApp);
        }
    }

    public void delete (String appPackageName){
        appRepository.deleteAppFromDatabase(appPackageName);
    }

    public void deleteAllApps () {
        appRepository.deleteAllApps();
    }

    public LockApp getAppByPackageName (String appPackageName) {
        return appRepository.getAppFromDatabase(appPackageName);
    }

    public LiveData<List<LockApp>> getLockAppsList () {
        if (lockAppsList == null){
            lockAppsList = appRepository.getAllLockApps();
        }
        return lockAppsList;
    }

    public ArrayList<String> getLockedAppsPackageName () {
        List<LockApp> allLockApps = getAllApps();
        ArrayList<String> lockedAppsStringList = new ArrayList<>();

        for (LockApp lockApp: allLockApps){
            lockedAppsStringList.add(lockApp.appPackageName);
        }

        return lockedAppsStringList;
    }

    public List<LockApp> getAllApps () {
        return appRepository.getAllApps();
    }
}
