package com.example.secureapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class OneTimeWelcomeActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    CheckBox agreementCheckBox;
    MyApplication myApplication;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myApplication = ((MyApplication) getApplicationContext());
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        setContentView(R.layout.activity_one_time_welcome);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void startProtectingButton(View view) {
        agreementCheckBox = findViewById(R.id.agreementCheckBox);
        if (agreementCheckBox.isChecked()){
            sharedPreferences.edit().putBoolean("agreement", true).apply();
            if (GlobalClass.isRequiredPermissionGranted(getApplicationContext(), getPackageManager())){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }else{
                GlobalClass.checkPermissionAndStartPermit(getPackageManager(), getApplicationContext());
                finish();
            }
        }else{
            Toast.makeText(this, "Please check the agreement", Toast.LENGTH_SHORT).show();
        }
    }
}