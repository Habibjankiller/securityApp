package com.example.secureapp;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;

public class PasswordRepository {
    private HashEntityDao hashEntityDao;
    private LiveData<List<HashEntity>> listLiveDataHashEntities;

    public PasswordRepository(Context context) {
        LockedAppsDatabase lockedAppsDatabase = LockedAppsDatabase.getInstance(context);
        hashEntityDao = lockedAppsDatabase.hashEntityDao();
        listLiveDataHashEntities = hashEntityDao.getPasswords();
    }

    public void clearAllPasswords() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                hashEntityDao.deleteAllPasswords();
            }
        }).start();
    }

    public LiveData<List<HashEntity>> getAllPasswords () {
        if (listLiveDataHashEntities == null){
            listLiveDataHashEntities = hashEntityDao.getPasswords();
        }
        return listLiveDataHashEntities;
    }

    public HashEntity getPasswordByType(String type) {
        return hashEntityDao.getHashByType(type);
    }

    public void updateEntity(HashEntity hashEntity){
        hashEntityDao.updateEntity(hashEntity);
    }

    public void insert(HashEntity hashEntity) {
        hashEntityDao.insert(hashEntity);
    }
    public HashEntity getHash (String hash){
        return hashEntityDao.getHash(hash);
    }
    public void deleteHash (HashEntity hashEntity){
        hashEntityDao.deleteHash(hashEntity.password_hash);
    }
}
