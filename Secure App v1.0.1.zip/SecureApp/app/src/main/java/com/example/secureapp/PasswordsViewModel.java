package com.example.secureapp;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class PasswordsViewModel extends AndroidViewModel {
    private PasswordRepository passwordRepository;
    private LiveData<List<HashEntity>> listLiveDataHash;

    public PasswordsViewModel(Application application) {
        super(application);

        passwordRepository = new PasswordRepository(application);
        listLiveDataHash = passwordRepository.getAllPasswords();
    }

    public LiveData<List<HashEntity>> getAllPasswords () {
        if (listLiveDataHash == null){
            listLiveDataHash = passwordRepository.getAllPasswords();
        }

        return listLiveDataHash;
    }

    public HashEntity getHashByType (String type){
        return passwordRepository.getPasswordByType(type);
    }

    public void insertHash(HashEntity hashEntity) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HashEntity alreadyExistHash = passwordRepository.getPasswordByType(hashEntity.password_type);
                if (alreadyExistHash != null){
                    passwordRepository.deleteHash(alreadyExistHash);
                    Log.d("backgroundtask", "Already hash");
                }else{

                    Log.d("backgroundtask", "Not Hash");
                }
                passwordRepository.insert(hashEntity);
            }
        }).start();
    }

    public HashEntity getHash (String hash) {
        return passwordRepository.getHash(hash);
    }
}
