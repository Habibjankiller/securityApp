package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;
import com.bumptech.glide.Glide;
import com.google.android.ads.nativetemplates.TemplateView;

import java.util.List;
import java.util.regex.Pattern;

public class PatternAuthenticationActivity extends AppCompatActivity {
    PatternLockView patternLockView;
    ImageView appIcon;
    String appPackageName;
    Handler handler;

    //Ad View
    LinearLayout parentViewGroup;

    //LiveData + ViewModel
    PasswordsViewModel passwordsViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pattern_authentication);

        //Initilizing variables
        parentViewGroup = findViewById(R.id.parentViewGroup);
        patternLockView = findViewById(R.id.unlockAppPatternView);
        appIcon = findViewById(R.id.appIcon);
        appPackageName = getIntent().getExtras().getString("openedApp");
        handler = new Handler();

        passwordsViewModel = new PasswordsViewModel(getApplication());

        try {
            appIcon.setImageDrawable(getPackageManager().getApplicationIcon(appPackageName));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        patternLockView.setDotCount(3);
        patternLockView.setAspectRatioEnabled(true);
        patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
        patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
        patternLockView.setDotAnimationDuration(150);
        patternLockView.setPathEndAnimationDuration(100);
        patternLockView.setInStealthMode(false);
        patternLockView.setTactileFeedbackEnabled(true);
        patternLockView.setInputEnabled(true);
        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if (pattern.size() < 4){
                    Toast.makeText(PatternAuthenticationActivity.this, "Draw Four", Toast.LENGTH_SHORT).show();
                    patternLockView.clearPattern();
                }else{
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                String patternToMD5 = PatternLockUtils.patternToMD5(patternLockView, pattern);
                                HashEntity hashEntity = passwordsViewModel.getHash(patternToMD5);
                                if (hashEntity != null){
                                    handler.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (hashEntity.password_hash.equals(patternToMD5)){
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                                    finishAndRemoveTask();
                                                }else{
                                                    finish();
                                                }
                                            }else{
                                                Toast.makeText(PatternAuthenticationActivity.this, "wrong pattern", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }else{
                                    patternLockView.clearPattern();
                                }
                            }
                        }).start();

                    }
                }

            @Override
            public void onCleared() {

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}