package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import org.w3c.dom.Text;

import java.util.List;
import java.util.regex.Pattern;

public class PatternLockChoosingActivity extends AppCompatActivity {
    private static final String ALGO = "MD5";
    PatternLockView patternLockView;
    private String tryFirst = "";
    private String trySecond = "";
    MyApplication myApplication;
    private boolean isFirst = true;
    TextView textView;

    //ViewModel Variables
    PasswordsViewModel passwordsViewModel;
    LiveData<List<HashEntity>> listLiveDataHash;

    //SharedPreferences
    SharedPreferences sharedPreferences;

    //HASHType
    private String passwordType = "pattern";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pattern_lock_choosing);
        myApplication = ((MyApplication) getApplicationContext());

        textView = findViewById(R.id.dialog_text_view);
        passwordsViewModel = new PasswordsViewModel(getApplication());
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        setPatternLockView();
    }


    public void setPatternLockView () {
        patternLockView = findViewById(R.id.setting_pattern_lock);
        patternLockView.setDotCount(3);
        patternLockView.setAspectRatioEnabled(true);
        patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
        patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
        patternLockView.setDotAnimationDuration(150);
        patternLockView.setPathEndAnimationDuration(100);
        patternLockView.setInStealthMode(false);
        patternLockView.setTactileFeedbackEnabled(true);
        patternLockView.setInputEnabled(true);
        patternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if (pattern.size() < 4){
                    patternLockView.clearPattern();
                }else{
                    if (isFirst){
                        tryFirst = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        textView.setText(R.string.redraw_pattern_to_confirm);
                        isFirst = false;
                        patternLockView.clearPattern();
                    }else{
                        trySecond = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        if (tryFirst.equals(trySecond)){
                            Toast.makeText(PatternLockChoosingActivity.this, "Pattern Match Successfully", Toast.LENGTH_SHORT).show();
                            HashEntity hashEntity = new HashEntity(passwordType, tryFirst);
                            passwordsViewModel.insertHash(hashEntity);
                            startActivity(new Intent(PatternLockChoosingActivity.this, MainActivity.class));
                            sharedPreferences.edit().putString(getString(R.string.lock_type), "pattern").apply();
                            finish();
                        }else{
                            Toast.makeText(PatternLockChoosingActivity.this, "Pattern Not match Try Again", Toast.LENGTH_SHORT).show();
                            textView.setText(R.string.draw_an_unlock_pattern);
                        }

                        isFirst = true;
                        patternLockView.clearPattern();
                    }
                }
            }

            @Override
            public void onCleared() {

            }
        });
    }
}