package com.example.secureapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.audiofx.BassBoost;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;

import java.util.List;

public class PermissionCheckingActivity extends AppCompatActivity {
    CardView overlayCardView;
    CardView usagestats_card_view;
    PasswordsViewModel passwordsViewModel;
    List<HashEntity> hashEntityList;
    Handler handler;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_checking);
        overlayCardView = findViewById(R.id.overlay_card_view);
        usagestats_card_view = findViewById(R.id.usagestats_card_view);
        passwordsViewModel = new PasswordsViewModel(getApplication());
        handler = new Handler();
        if (GlobalClass.isOverLayGranted(getApplicationContext())){
            overlayCardView.setVisibility(View.GONE);
        }
        if (GlobalClass.isUsageAccessGranted(getApplicationContext(), getPackageManager())){
            usagestats_card_view.setVisibility(View.GONE);
        }
        overlayCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(GlobalClass.isOverLayGranted(getApplicationContext()))){
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                        startActivity(intent);
                    }
                }
            }
        });

        usagestats_card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(GlobalClass.isUsageAccessGranted(getApplicationContext(), getPackageManager()))){
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                        startActivity(intent);
                    }
                }
            }
        });

        if (GlobalClass.isRequiredPermissionGranted(getApplicationContext(), getPackageManager())){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onResume() {
        super.onResume();
        if (GlobalClass.isOverLayGranted(getApplicationContext())){
            overlayCardView.setVisibility(View.GONE);
        }
        if (GlobalClass.isUsageAccessGranted(getApplicationContext(), getPackageManager())){
            usagestats_card_view.setVisibility(View.GONE);
        }

        if (GlobalClass.isRequiredPermissionGranted(getApplicationContext(), getPackageManager())){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    hashEntityList = passwordsViewModel.getAllPasswords().getValue();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (hashEntityList != null){
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                                finish();
                            }else{
                                Intent intent = new Intent(getApplicationContext(), PatternLockChoosingActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    });
                }
            }).start();
        }
    }
}