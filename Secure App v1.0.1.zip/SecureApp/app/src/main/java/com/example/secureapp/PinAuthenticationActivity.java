package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class PinAuthenticationActivity extends AppCompatActivity {
    TextView textView;
    String openedAppPackageName;
    EditText editText;
    PasswordsViewModel passwordsViewModel;
    Handler handler;
    SharedPreferences sharedPreferences;
    ApplicationUtils applicationUtils;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_authentication);

        //Vairables Initialization
        sharedPreferences = getSharedPreferences(getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        applicationUtils = ApplicationUtils.initialize(getApplication());
        editText = findViewById(R.id.pinVerify);
        textView = findViewById(R.id.appNameTextView);
        Intent intent = getIntent();
        openedAppPackageName = intent.getStringExtra("openedApp");
        ApplicationInfo applicationInfo = null;
        handler = new Handler();
        String appLabel = "";
        passwordsViewModel = new PasswordsViewModel(getApplication());

        PackageManager packageManager = getPackageManager();
        try {
            applicationInfo = packageManager.getApplicationInfo(openedAppPackageName, PackageManager.GET_META_DATA);
            appLabel = applicationInfo.loadLabel(packageManager).toString();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
//        textView.setText(appLabel+"  is Locked, Please Enter your password to continue");

    }

    public void doUnlockApp(View view) {
        String regularText = editText.getText().toString();
        String encryptedText = PinLockChoosingActivity.encryptText(regularText);

        String encryptedPasswordFromDb = "";
        new Thread(new Runnable() {
            @Override
            public void run() {
                HashEntity hashEntity = passwordsViewModel.getHash(encryptedText);
                if (hashEntity != null){

                    applicationUtils.unlockApp(openedAppPackageName);

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                finishAndRemoveTask();
                            }else{
                                finish();
                            }
                        }
                    });
                }else{
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(PinAuthenticationActivity.this, "Wrong password detected", Toast.LENGTH_SHORT).show();
                            editText.setText("");
                        }
                    });
                }
            }
        }).start();



    }

    @Override
    public void onBackPressed() {
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(startMain);
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }

    public void figureClicked(View view) {
        Button button = (Button) view;
        int clickedNumber = Integer.parseInt(button.getText().toString());
        editText.setText(editText.getText().toString() + clickedNumber);
    }

    public void allClear(View view) {
        editText.setText("");
    }

    public void setPassword(View view) {

    }

//    public void clearChar(View view) {
//        String text = String.valueOf(editText.getText());
//        text.
//    }
}