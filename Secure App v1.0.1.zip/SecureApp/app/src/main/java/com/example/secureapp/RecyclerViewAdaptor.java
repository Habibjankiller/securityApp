package com.example.secureapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class RecyclerViewAdaptor extends RecyclerView.Adapter<RecyclerViewAdaptor.ViewHolder> {
    ArrayList<ApplicationInfo> applicationInfos;
    PackageManager packageManager;
    Context context;
//    SQLiteDatabase sqLiteDatabase;
    LockedAppsDatabase lockedAppsDatabase;
    LockedAppsDao lockedAppsDao;

    GlobalClass GlobalClass;
    public RecyclerViewAdaptor(
            Context context,
            ArrayList<ApplicationInfo> applicationInfos,
            PackageManager packageManager,
            SQLiteDatabase sqLiteDatabase) {
        this.context = context;
        this.applicationInfos = applicationInfos;
        this.packageManager = packageManager;
//        this.sqLiteDatabase = sqLiteDatabase;
        lockedAppsDatabase = LockedAppsDatabase.getInstance(context);
        lockedAppsDao = lockedAppsDatabase.lockAppsDao();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.app_list_item_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApplicationInfo applicationInfo = applicationInfos.get(position);
        String appName = (String) packageManager.getApplicationLabel(applicationInfo);
        String packageName = applicationInfo.packageName;
        Drawable appIcon = applicationInfo.loadIcon(packageManager);
        Glide.with(context.getApplicationContext()).load(appIcon).into(holder.appIcon);
        holder.app_name.setText(appName);
        final boolean[] appIsLocked = {false};
        ImageView statusSwitch = holder.statusSwitch;
        Resources resources = context.getResources();
        Drawable lockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.locked_toggle, null);
        Drawable unlockDrawable = ResourcesCompat.getDrawable(resources, R.drawable.unlock_toggle, null);
        LockApp lockApp = lockedAppsDao.getLockAppByPackageName(packageName);

        if (lockApp != null){
            holder.statusSwitch.setImageDrawable(lockDrawable);
            appIsLocked[0] = true;
        }else{
            appIsLocked[0] = false;
            holder.statusSwitch.setImageDrawable(unlockDrawable);
        }


        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                if (!(GlobalClass.isUsageAccessGranted(context, packageManager))){
                    AlertDialog alertDialog = new AlertDialog.Builder(context)
                            .setTitle("Permission Needed")
                            .setMessage("In the Beginning of Android 5.0 You must access to Android Usage Access Permission in order to make your app secure")
                            .setPositiveButton("Grant Permission", new DialogInterface.OnClickListener() {
                                @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                                    context.startActivity(intent);
                                }
                            })
                            .setNegativeButton("Cancle", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(context, "Dismiss", Toast.LENGTH_SHORT).show();
                                }
                            }).create();
                    alertDialog.show();

                }else{
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (GlobalClass.isOverLayGranted(context)){
                            if (appIsLocked[0]){
                                LockApp appToDelete = new LockApp(appName, packageName);
                                lockedAppsDao.deleteLockApp(appToDelete);
                                appIsLocked[0] = false;
                                holder.statusSwitch.setImageDrawable(unlockDrawable);
                            }else{
                                LockApp appToLock = new LockApp(appName, packageName);
                                lockedAppsDao.insertApps(appToLock);
                                holder.statusSwitch.setImageDrawable(lockDrawable);
                                appIsLocked[0] = true;
                                Toast.makeText(context, appName +": is Locked", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            AlertDialog alertDialog = new AlertDialog.Builder(context)
                                    .setTitle("NEED PERMISSION!")
                                    .setMessage("Draw over other apps permission is needed to activate advance Secure Mode")
                                    .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                                            context.startActivity(intent);
                                        }
                                    })
                                    .create();
                            alertDialog.show();
                        }
                    }
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return applicationInfos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout relativeLayout;
        ImageView appIcon;
        TextView app_name;
        ImageView statusSwitch;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            relativeLayout = itemView.findViewById(R.id.relative_layout);
            appIcon = itemView.findViewById(R.id.app_icon);
            app_name = itemView.findViewById(R.id.app_name);
            statusSwitch = itemView.findViewById(R.id.lock_switch);
        }
    }

}
