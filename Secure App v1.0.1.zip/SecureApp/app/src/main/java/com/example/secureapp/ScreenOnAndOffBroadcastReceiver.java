package com.example.secureapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.common.util.AndroidUtilsLight;

import java.util.ArrayList;

public class ScreenOnAndOffBroadcastReceiver extends BroadcastReceiver {
    MyApplication application;
    ApplicationUtils applicationUtils;
    @Override
    public void onReceive(Context context, Intent intent) {

        application = (MyApplication) context.getApplicationContext();
        applicationUtils = ApplicationUtils.initialize(application);

        if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)){
            if (applicationUtils.isRelockAfterScreenOn()){
                applicationUtils.setUnlockedApps(new ArrayList<>());
            }
            applicationUtils.setLastUnlockedApp("");
            ForegroundService.opened_app = "";
            Log.d("backgroundtask", "Screen On Receive");
        }
    }
}
