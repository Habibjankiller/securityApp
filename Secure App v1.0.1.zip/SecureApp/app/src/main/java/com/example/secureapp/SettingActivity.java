package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class SettingActivity extends AppCompatActivity {
    private ArrayList<ActivityManager.RunningServiceInfo> runningServiceInfos;
    private SharedPreferences sharedPreferences;
    public Drawable locked_status_drawable;
    public Drawable unlocked_status_drawable;


    //Toggles;
    ImageView lockAfterScreenOnToggleView;
    TextView lockTypeStatusTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        locked_status_drawable = getResources().getDrawable(R.drawable.locked_toggle);
        unlocked_status_drawable = getResources().getDrawable(R.drawable.unlock_toggle);

        lockTypeStatusTextView = findViewById(R.id.lock_type_status);
        lockAfterScreenOnToggleView = findViewById(R.id.screen_on_lock_switch);

        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        lockTypeStatusTextView.setText(sharedPreferences.getString("lock_type", "pattern"));

        setPreferencesToggles();
    }

    public void finishActivity(View view) {
        finish();
    }

    public void openUnlockSetting(View view) {
        Intent intent = new Intent(SettingActivity.this, lock_settings.class);
        startActivity(intent);
    }



    public void openPatternLockChoosingActivity(View view) {
        Intent intent = new Intent(getApplicationContext(), PatternLockChoosingActivity.class);
        startActivity(intent);
    }

    public void setPreferencesToggles () {

        if (sharedPreferences.getBoolean(getString(R.string.lock_after_screen_on_preferences), false)){
            lockAfterScreenOnToggleView.setImageDrawable(locked_status_drawable);
        }else{
            lockAfterScreenOnToggleView.setImageDrawable(unlocked_status_drawable);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setPreferencesToggles();
    }

    public void toggle_intruder_detection(View view) {
        if (sharedPreferences.getBoolean(getResources().getString(R.string.intruder_detection_preference), false)){
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.intruder_detection_preference), false).apply();
        }else{
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.intruder_detection_preference), true).apply();
        }

        Toast.makeText(this, "Intruder detection toggle", Toast.LENGTH_SHORT).show();
    }

    public void toggle_random_animation(View view) {
        if (sharedPreferences.getBoolean(getResources().getString(R.string.random_animation_preference), false)){
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.random_animation_preference), false).apply();
        }else{
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.random_animation_preference), true).apply();
        }

        Toast.makeText(this, "Random animation toggle", Toast.LENGTH_SHORT).show();
    }

    public void toggle_apply_cover(View view) {
        if (sharedPreferences.getBoolean(getResources().getString(R.string.apply_cover_preference), false)){
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.apply_cover_preference), false).apply();
        }else{
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.apply_cover_preference), true).apply();
        }

        Toast.makeText(this, "Apply cover toggle", Toast.LENGTH_SHORT).show();
    }

    public void toggle_screen_on_lock(View view) {
        if (sharedPreferences.getBoolean(getResources().getString(R.string.lock_after_screen_on_preferences), false)){
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.lock_after_screen_on_preferences), false).apply();
        }else{
            sharedPreferences.edit().putBoolean(getResources().getString(R.string.lock_after_screen_on_preferences), true).apply();
        }

        if (sharedPreferences.getBoolean(getResources().getString(R.string.lock_after_screen_on_preferences), false)){
            lockAfterScreenOnToggleView.setImageDrawable(locked_status_drawable);
        }else{
            lockAfterScreenOnToggleView.setImageDrawable(unlocked_status_drawable);
        }

        Toast.makeText(this, "Apply screen on toggle", Toast.LENGTH_SHORT).show();
    }
}