package com.example.secureapp;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link lock_apps#newInstance} factory method to
 * create an instance of this fragment.
 */
public class lock_apps extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    //ViewModel
    LockAppsViewModel lockAppsViewModel;

    //Layout Variables
    LinearLayout lockAppLinearLayout;

    //Package Manager
    PackageManager packageManager;

    //Layout Inflator
    LayoutInflater layoutInflater;

    //UI Handler Thread
    Handler uiHandler;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public lock_apps() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment lock_apps.
     */
    // TODO: Rename and change types and number of parameters
    public static lock_apps newInstance(String param1, String param2) {
        lock_apps fragment = new lock_apps();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_lock_apps, container, false);

        lockAppsViewModel = new LockAppsViewModel(getActivity().getApplication());
        lockAppLinearLayout = view.findViewById(R.id.locked_apps_linear_layout);
        packageManager = getContext().getPackageManager();
        layoutInflater = getLayoutInflater();
        uiHandler = new Handler();
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<LockApp> lockedApps = lockAppsViewModel.getAllApps();
                for (LockApp lockApp: lockedApps){
                    try {
                        ApplicationInfo applicationInfo = packageManager.getApplicationInfo(lockApp.appPackageName, 0);
                        uiHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                addView(lockAppLinearLayout, applicationInfo);
                            }
                        });
                    } catch (PackageManager.NameNotFoundException e) {
                        return;
                    }
                }
            }
        }).start();
        return view;
    }

    void addView (LinearLayout linearLayout, ApplicationInfo applicationInfo){
        View appView = layoutInflater.inflate(R.layout.app_list_item_design, linearLayout, false);
        ImageView iconImageView = appView.findViewById(R.id.app_icon);
        TextView appName = appView.findViewById(R.id.app_name);
        RelativeLayout appViewLayout = appView.findViewById(R.id.relative_layout);
        ImageView statusSwitch = appView.findViewById(R.id.lock_switch);
        new Thread(new Runnable() {
            @Override
            public void run() {
                LockApp isAppLock = lockAppsViewModel.getAppByPackageName(applicationInfo.packageName);
                if (isAppLock != null){
                    uiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            statusSwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));

                        }
                    });
                }else{
                    uiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            statusSwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
                        }
                    });
                }
            }
        }).start();

        appName.setText(applicationInfo.loadLabel(packageManager));
        iconImageView.setImageDrawable(applicationInfo.loadIcon(packageManager));
        appViewLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LockApp lockApp = new LockApp(applicationInfo.loadLabel(packageManager).toString(), applicationInfo.packageName);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (lockAppsViewModel.getAppByPackageName(lockApp.appPackageName) != null){
                            lockAppsViewModel.delete(applicationInfo.packageName);
                            statusSwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
                        }else{
                            lockAppsViewModel.insertApp(lockApp);
                            statusSwitch.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));
                        }
                    }
                }).start();
            }
        });
        linearLayout.addView(appView);
    }
}