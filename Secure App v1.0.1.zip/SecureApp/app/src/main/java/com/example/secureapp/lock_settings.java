package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class lock_settings extends AppCompatActivity {
    NoScrollingViewPager noScrollingViewPager;
    UnlockSettingViewPagerAdaptor unlockSettingViewPagerAdaptor;

    LinearLayout pinLinearLayoutButton;
    LinearLayout patternLinearLayoutButton;
    TextView pinTextView;
    TextView patternTextView;

    SharedPreferences sharedPreferences;
    private String unlockMethod;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock_settings);
        noScrollingViewPager = findViewById(R.id.unlock_setting_view_pager);
        sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        pinLinearLayoutButton = findViewById(R.id.pin_layout_button);
        patternLinearLayoutButton = findViewById(R.id.pattern_layout_button);
        pinTextView = findViewById(R.id.pin_layout_text);
        patternTextView = findViewById(R.id.pattern_layout_text);

        unlockMethod = sharedPreferences.getString("lock_type", "none");
        if (unlockMethod.equals("pin")){
            GlobalClass.selectTab(getApplicationContext(), pinLinearLayoutButton, pinTextView);
            GlobalClass.unSelectTab(getApplicationContext(), patternLinearLayoutButton, patternTextView);
            noScrollingViewPager.setCurrentItem(0, false);
        }else if (unlockMethod.equals("pattern")){
            GlobalClass.selectTab(getApplicationContext(), patternLinearLayoutButton, patternTextView);
            GlobalClass.unSelectTab(getApplicationContext(), pinLinearLayoutButton, pinTextView);
            noScrollingViewPager.setCurrentItem(1, false);
        }
        noScrollingViewPager.setPagingEnabled(false);
        unlockSettingViewPagerAdaptor = new UnlockSettingViewPagerAdaptor(getSupportFragmentManager());
        noScrollingViewPager.setAdapter(unlockSettingViewPagerAdaptor);
        pinLinearLayoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(lock_settings.this, PinLockChoosingActivity.class);
                startActivity(intent);
            }
        });
        patternLinearLayoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(lock_settings.this, PatternLockChoosingActivity.class);
                startActivity(intent);
            }
        });


    }

    public void finishActivity(View view) {
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        unlockMethod = sharedPreferences.getString("lock_type", "none");
        if (unlockMethod.equals("pin")){
            GlobalClass.selectTab(getApplicationContext(), pinLinearLayoutButton, pinTextView);
            GlobalClass.unSelectTab(getApplicationContext(), patternLinearLayoutButton, patternTextView);
            noScrollingViewPager.setCurrentItem(0, false);
        }else if (unlockMethod.equals("pattern")){
            GlobalClass.selectTab(getApplicationContext(), patternLinearLayoutButton, patternTextView);
            GlobalClass.unSelectTab(getApplicationContext(), pinLinearLayoutButton, pinTextView);
            noScrollingViewPager.setCurrentItem(1, false);
        }
    }
}