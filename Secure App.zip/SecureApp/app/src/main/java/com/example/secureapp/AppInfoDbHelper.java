package com.example.secureapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import androidx.annotation.Nullable;

public class AppInfoDbHelper extends SQLiteOpenHelper{
    private static int DATABASE_VERSION = 1;
    /**
     * Some Database Info
     */
    public static String DB_NAME = "apps_info_database";
    public static int DB_VERSION = 1;


    /**
     * Some predefined SQL Queries
     * for easier
     */
    //Query for Create locked_apps Table
    private static String SQL_CREATE_TABLE_FOR_LOCKED_APPS =
            "CREATE TABLE "+AppEntry.TABLE_NAME+" " +
                    "( "
                    +AppEntry._ID+" INTEGER PRIMARY KEY," +
                    AppEntry.COLUMN_APP_NAME+" TEXT,"+
                    AppEntry.COLUMN_APP_PKGNAME+" TEXT, "+
                    AppEntry.COLUMN_ISLOCKED+" TEXT" +
                    ")";

    private static String SQL_CREATE_TABLE_FOR_HASHED_PASSWORD =
            "CREATE TABLE "+HashEntry.TABLE_NAME+" " +
                    "("
                    +HashEntry._ID+", INTEGER PRIMARY KEY, "
                    +HashEntry.COLUMN_HASH_TYPE+" TEXT, "
                    +HashEntry.COLUME_HASHED+" TEXT" +
                    ")";



    //Query for Deleting Table if exists
    private static String SQL_DELETE_TABLE = "DROP TABLE IF EXIST " + AppEntry.TABLE_NAME;

    public AppInfoDbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_FOR_HASHED_PASSWORD);
        db.execSQL(SQL_CREATE_TABLE_FOR_LOCKED_APPS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    class AppEntry implements BaseColumns{
        public static final String TABLE_NAME = "locked_apps";
        public static final String COLUMN_APP_NAME = "app_name";
        public static final String COLUMN_APP_PKGNAME = "package_name";
        public static final String COLUMN_ISLOCKED = "is_locked";
    }

    class HashEntry implements BaseColumns{
        public static final String TABLE_NAME = "hash_table";
        public static final String COLUMN_HASH_TYPE = "hash_type";
        public static final String COLUME_HASHED = "hashed_password";
    }
}
