package com.example.secureapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ForegroundService extends Service {
    public static int FOREGROUND_SERVICE_ID = 124;
    public static String FOREGROUND_NOTIFICATION_CHANNEL_ID = "foreground_notification";
    NotificationManager notificationManager;
    NotificationChannel notificationChannel;
    Notification foregroundNotification;
    PendingIntent pendingIntentNotification;
    Intent notificationIntent;
    Intent lockIntent;
    ExecutorService executorService;
    private static int APPLICATION_OPENED_FLAG = 0;
    public static String unlockedApp = "";
    private UsageStatsManager usageStatsManager;
    private static String opened_app = "";
    private IntentFilter intentFilter;
    private BroadcastReceiver broadcastReceiver;
    private AppInfoDbHelper appInfoDbHelper;
    private SQLiteDatabase sqLiteDatabase;
    private String lockType = "none";
    public static String lock_type = "";
    Handler lockHandler;

    //Overlay Objects
    WindowManager windowManager;
    View lockView;
    WindowManager.LayoutParams layoutParams;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onCreate() {
        super.onCreate();
        executorService = Executors.newFixedThreadPool(1);
        lockType = getSharedPreferences(
                getResources().getString(R.string.myAppSharedPreferences),
                Context.MODE_PRIVATE)
                .getString("lock_type", "none");
        lock_type = lockType;
        windowManager = (WindowManager) getSystemService(Service.WINDOW_SERVICE);
        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS |
                        WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION |
                        WindowManager.LayoutParams.FLAG_DIM_BEHIND |
                        WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
                );

        LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
        if (lockType.equals("pin")){
            lockView = layoutInflater.inflate(R.layout.pin_lock_authentication_overlay, null, false);
        }else{
            lockView = layoutInflater.inflate(R.layout.pattern_lock_authentication_overlay, null, false);
        }
        notificationIntent = new Intent(this, MainActivity.class);
        intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_USER_PRESENT);
        intentFilter.addAction(Intent.ACTION_USER_UNLOCKED);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        broadcastReceiver = new startForegroundAfterDeviceBoot();
        IntentFilter intentFilter = new IntentFilter(Intent.ACTION_USER_UNLOCKED);
        getApplicationContext().registerReceiver(broadcastReceiver, intentFilter);
        lockHandler = new Handler();
        pendingIntentNotification = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        appInfoDbHelper = new AppInfoDbHelper(getBaseContext());
        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                sqLiteDatabase = appInfoDbHelper.getReadableDatabase();
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationChannel = new NotificationChannel(
                    FOREGROUND_NOTIFICATION_CHANNEL_ID,
                    "Notification Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            usageStatsManager = (UsageStatsManager) getBaseContext().getSystemService(Context.USAGE_STATS_SERVICE);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        foregroundNotification = new NotificationCompat.Builder(this, FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setContentIntent(pendingIntentNotification)
                .setContentText("Securing Your App")
                .setChannelId(FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setOngoing(true)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(getResources().getString(R.string.app_name)).build();

        executorService.execute(new Runnable() {
            @Override
            public void run() {

                if (Looper.myLooper() == null){
                    Looper.prepare();
                }
                Timer timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() {
                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void run() {

                        /*
                        Getting Application Infoes from UsageStatsManager
                         */
                        String result = null;
                        String runningApp = getRunningApplication();
                        if (!(runningApp == null)  && !(runningApp.equalsIgnoreCase(getPackageName())) && !(runningApp.equalsIgnoreCase(opened_app))){
                            Log.d("backgroundTask", runningApp+" has been foregrounded");
                            lockHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    lockView.setVisibility(View.GONE);
                                }
                            });
                            opened_app = runningApp;
                            APPLICATION_OPENED_FLAG = 0;
                            String SQL_SELECT_APP_QUERY = "SELECT "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME +" FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME+" WHERE "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME+" = '" + runningApp+"'";
                            Cursor cursor = sqLiteDatabase.rawQuery(SQL_SELECT_APP_QUERY, new String[]{});
                            if (cursor.getCount() > 0){
                                cursor.moveToNext();
                                result = cursor.getString(0);
                            }

                            if (runningApp.equals(result)){
                                if (APPLICATION_OPENED_FLAG == 0){
                                    if (runningApp.equals("com.android.settings")){
                                        Log.d("backgroundtask", "Setting App has been opened");
                                        lockView.setVisibility(View.GONE);
                                        if (lock_type.equals("pin")){
                                            lockIntent = new Intent(getApplicationContext(), PinAuthenticationActivity.class);
                                            //SET ACTIVITY FLAGS
                                            lockIntent.setFlags(
                                                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                                                            Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                                            Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                                            Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
                                                            Intent.FLAG_FROM_BACKGROUND
                                            );
                                        }else{
                                            lockIntent = new Intent(getApplicationContext(), PatternAuthenticationActivity.class);
                                            lockIntent.setFlags(
                                                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                                                            Intent.FLAG_ACTIVITY_SINGLE_TOP |
                                                            Intent.FLAG_ACTIVITY_NEW_TASK |
                                                            Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT |
                                                            Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED |
                                                            Intent.FLAG_FROM_BACKGROUND
                                            );
                                            //SET ACTIVITY FLAGS
                                        }
                                        lockIntent.putExtra("openedApp", opened_app);
                                        startActivity(lockIntent);
                                        //RUN LOCK ACTIVITY
                                        APPLICATION_OPENED_FLAG = 1;
                                    }else{
                                        setLockView(lock_type);
                                    }

                                }
                            }
                        }
                    }
                }, 0, 500);

        }});


        startForeground(FOREGROUND_SERVICE_ID, foregroundNotification);
        return START_STICKY;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private String getRunningApplication () {
            Long endTime = System.currentTimeMillis();
        Long beginTime = endTime - 1000;
        UsageEvents usageEvents = usageStatsManager.queryEvents(beginTime, endTime);
        UsageEvents.Event event = new UsageEvents.Event();

        while (usageEvents.hasNextEvent()){
            usageEvents.getNextEvent(event);
            if (event.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED){
                return event.getPackageName();
            }
        }
        return null;
    }

    public int getNavigationBarHeight () {
        Resources resources = getBaseContext().getResources();
        int orientation = 0;
        int id = resources.getIdentifier(
                orientation == getBaseContext().getResources().getConfiguration().orientation ? "navigation_bar_height" : "navigation_bar_height_landscape",
                "dimen", "android");
        if (id > 0) {
            return resources.getDimensionPixelSize(id);
        }else{
            return 0;
        }
    }

    private void setLockView (String string) {
        if (string.equals("pin")){
            lockView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pin_lock_authentication_overlay, null, false);
            EditText editText = lockView.findViewById(R.id.pinVerify);
            ImageView imageView = lockView.findViewById(R.id.clearButton);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editText.setText("");
                }
            });
            Button button = lockView.findViewWithTag("figureButton");
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int clickedNumber = Integer.parseInt(button.getText().toString());
                    editText.setText(editText.getText().toString() + clickedNumber);
                }
            });

            lockHandler.post(new Runnable() {
                @Override
                public void run() {
                    windowManager.addView(lockView, layoutParams);
                    lockView.setVisibility(View.VISIBLE);
                }
            });
        }else{
            lockView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.pattern_lock_authentication_overlay, null, false);
            ImageView appIcon = lockView.findViewById(R.id.appIcon);
            PatternLockView patternLockView = lockView.findViewById(R.id.unlockAppPatternView);

            try {
                appIcon.setImageDrawable(getPackageManager().getApplicationIcon(opened_app));
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            final String[] encryptedPasswordFromDb = new String[1];
            String SQL_GET_HASHED_PASSWORD = "SELECT "+ AppInfoDbHelper.HashEntry.COLUME_HASHED+" FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
            Cursor cursor = sqLiteDatabase.rawQuery(SQL_GET_HASHED_PASSWORD, null);
            if (cursor.getCount() > 0) {
                cursor.moveToNext();
                encryptedPasswordFromDb[0] = cursor.getString(0);
            }

            patternLockView.setDotCount(3);
            patternLockView.setAspectRatioEnabled(true);
            patternLockView.setAspectRatio(PatternLockView.AspectRatio.ASPECT_RATIO_HEIGHT_BIAS);
            patternLockView.setViewMode(PatternLockView.PatternViewMode.CORRECT);
            patternLockView.setDotAnimationDuration(150);
            patternLockView.setPathEndAnimationDuration(100);
            patternLockView.setInStealthMode(false);
            patternLockView.setTactileFeedbackEnabled(true);
            patternLockView.setInputEnabled(true);
            patternLockView.addPatternLockListener(new PatternLockViewListener() {
                @Override
                public void onStarted() {

                }

                @Override
                public void onProgress(List<PatternLockView.Dot> progressPattern) {

                }

                @Override
                public void onComplete(List<PatternLockView.Dot> pattern) {
                    if (pattern.size() < 4){
                        Toast.makeText(getApplicationContext(), "Draw Four", Toast.LENGTH_SHORT).show();
                        patternLockView.clearPattern();
                    }else{
                        String patternToMD5 = PatternLockUtils.patternToMD5(patternLockView, pattern);
                        if (encryptedPasswordFromDb[0].equals(patternToMD5)){
                            lockHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    lockView.setVisibility(View.GONE);
                                }
                            });
                            APPLICATION_OPENED_FLAG = 1;
                        }else{
                            patternLockView.clearPattern();
                            Toast.makeText(getBaseContext(), "Wrong Pattern Detected", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onCleared() {

                }
            });

            lockHandler.post(new Runnable() {
                @Override
                public void run() {
                    windowManager.addView(lockView, layoutParams);
                    lockView.setVisibility(View.VISIBLE);
                }
            });
        }
    }
}
