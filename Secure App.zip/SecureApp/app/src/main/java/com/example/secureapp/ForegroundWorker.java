package com.example.secureapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.work.ForegroundInfo;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ForegroundWorker extends Worker {

    public static int FOREGROUND_SERVICE_ID = 124;
    public static String FOREGROUND_NOTIFICATION_CHANNEL_ID = "foreground_notification";
    NotificationManager notificationManager;
    NotificationChannel notificationChannel;
    PendingIntent pendingIntentNotification;
    PendingIntent pendingAuthIntent;
    Intent authIntent;
    Intent notificationIntent;

    Context context;

    ExecutorService executorService;

    public static ArrayList<String> unlockedApps = new ArrayList<>();
    private TreeMap<Long, UsageStats> sortedUsageStatsList;
    private UsageStatsManager usageStatsManager;

    private IntentFilter intentFilter;
    private BroadcastReceiver broadcastReceiver;

    private AppInfoDbHelper appInfoDbHelper;
    private SQLiteDatabase sqLiteDatabase;

    public ForegroundWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
        this.context = context;

        executorService = Executors.newFixedThreadPool(1);

        notificationIntent = new Intent(context, MainActivity.class);
        authIntent = new Intent(context, PinAuthenticationActivity.class);
        authIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);

        intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_USER_PRESENT);
        intentFilter.addAction(Intent.ACTION_USER_UNLOCKED);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        broadcastReceiver = new startForegroundAfterDeviceBoot();

        authIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        authIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);

        pendingIntentNotification = PendingIntent.getActivity(context, 0, notificationIntent, 0);
        sortedUsageStatsList = new TreeMap<>();
        pendingAuthIntent = PendingIntent.getActivity(context, 1, authIntent, 0);
        appInfoDbHelper = new AppInfoDbHelper(context);
        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                sqLiteDatabase = appInfoDbHelper.getReadableDatabase();
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            usageStatsManager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationChannel = new NotificationChannel(
                    FOREGROUND_NOTIFICATION_CHANNEL_ID,
                    "Notification Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            notificationManager.createNotificationChannel(notificationChannel);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            usageStatsManager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        }

    }

    @NonNull
    @Override
    public Result doWork() {

        executorService.execute(new Runnable() {
            @Override
            public void run() {

                if (Looper.myLooper() == null){
                    Looper.prepare();
                }
                Timer timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        String result = null;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            String runningApp = getRunningApplication();
                            if (!runningApp.isEmpty()){
                                String SQL_SELECT_APP_QUERY = "SELECT "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME +" FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME+" WHERE "+ AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME+" = '" + runningApp+"'";
                                Cursor cursor = sqLiteDatabase.rawQuery(SQL_SELECT_APP_QUERY, new String[]{});
                                if (cursor.getCount() > 0){
                                    cursor.moveToNext();
                                    result = cursor.getString(0);
                                }

                                if (runningApp.equals(result)){
                                    if (unlockedApps.contains(runningApp)){
                                        Log.d("backgroundTask", "app is unlocked");
                                    }else{
                                        authIntent.putExtra("openedApp", runningApp);
                                        Log.d("backgroundTask", "app is locked");
                                        context.startActivity(authIntent);
                                    }
                                }
                            }else{
                                Log.d("backgroundTask", "no apps found running");
                            }
                        }
                    }
                }, 0, 300);

            }});
        setForegroundAsync(foregroundInfo());

        return Result.success();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private String getRunningApplication () {
        Long endTime = System.currentTimeMillis();
        Long startTime = endTime - 10000;
        List<UsageStats> usageStatsList = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, startTime, endTime);
        for (UsageStats usageStats: usageStatsList){
            sortedUsageStatsList.put(usageStats.getLastTimeUsed(), usageStats);
        }
        String lastApp = sortedUsageStatsList.get(sortedUsageStatsList.lastKey()).getPackageName();
        return lastApp;
    }

    private ForegroundInfo foregroundInfo () {
        Notification foregroundNotification = new NotificationCompat.Builder(context, FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setContentIntent(pendingIntentNotification)
                .setContentText("Securing Your App")
                .setChannelId(FOREGROUND_NOTIFICATION_CHANNEL_ID)
                .setOngoing(true)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle(getApplicationContext().getResources().getString(R.string.app_name)).build();

        return new ForegroundInfo(4, foregroundNotification);
    }
}
