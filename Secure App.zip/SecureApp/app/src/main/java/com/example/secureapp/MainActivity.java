package com.example.secureapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.IntentService;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.provider.Telephony;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

import java.net.Inet4Address;
import java.net.URI;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static boolean isFirstRun = true;
    //Application Info Variables
    PackageManager packageManager;
    ArrayList<ApplicationInfo> applicationInfos;

    //tab layout
    TabLayout tabLayout;

    //ViewPager Setup Variables
    ViewPagerAdaptor viewPagerAdaptor;
    NoScrollingViewPager viewPager;

    //Database Instance Variable
    AppInfoDbHelper appInfoDbHelper;
    SQLiteDatabase sqLiteDatabase;

    //ForegroundService Variables
    Intent serviceIntent;

    //WorkManager
    WorkManager workManager;
    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appInfoDbHelper = new AppInfoDbHelper(getApplicationContext());
        sqLiteDatabase = appInfoDbHelper.getReadableDatabase();
        String SQL_QUERY = "SELECT * FROM "+ AppInfoDbHelper.HashEntry.TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(SQL_QUERY, null);

        if (!(cursor.getCount() > 0)){
            Intent intent = new Intent(MainActivity.this, PatternLockChoosingActivity.class);
            startActivity(intent);
            finish();
        }else{
            Toast.makeText(this, "Password Already setted", Toast.LENGTH_SHORT).show();
        }
        //Creating Layout
        setContentView(R.layout.activity_main);

        //Variable Initialization
        tabLayout = findViewById(R.id.tab_layout);
        packageManager = getPackageManager();
        applicationInfos = (ArrayList<ApplicationInfo>) packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

        viewPagerAdaptor = new ViewPagerAdaptor(getSupportFragmentManager());
        viewPager = findViewById(R.id.all_apps_view_pager);
        viewPager.setAdapter(viewPagerAdaptor);
        tabLayout.setupWithViewPager(viewPager);
        serviceIntent = new Intent(this, ForegroundService.class);
        if (isAccessGranted(packageManager, this)){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if ((Settings.canDrawOverlays(getApplicationContext()))){
                    if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
                        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
                    }else{
                        ContextCompat.startForegroundService(this, serviceIntent);
                    }

                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static boolean isAccessGranted(PackageManager packageManager, Context context) {
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
            AppOpsManager appOpsManager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
            int mode = 0;
            if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.KITKAT) {
                mode = appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                        applicationInfo.uid, applicationInfo.packageName);
            }
            return (mode == AppOpsManager.MODE_ALLOWED);

        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onResume() {
        super.onResume();
        if (isAccessGranted(packageManager, this)){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if ((Settings.canDrawOverlays(getApplicationContext()))){
                    ContextCompat.startForegroundService(this, serviceIntent);
                }
            }
        }else{
            initOPPO();
        }
    }


    private void initOPPO() {
        try {

            Intent i = new Intent(Intent.ACTION_MAIN);
            i.setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.floatwindow.FloatWindowListActivity"));
            startActivity(i);
        } catch (Exception e) {
            e.printStackTrace();
            try {

                Intent intent = new Intent("action.coloros.safecenter.FloatWindowListActivity");
                intent.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.floatwindow.FloatWindowListActivity"));
                startActivity(intent);
            } catch (Exception ee) {

                ee.printStackTrace();
                try{

                    Intent i = new Intent("com.coloros.safecenter");
                    i.setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.sysfloatwindow.FloatWindowListActivity"));
                    startActivity(i);
                }catch (Exception e1){

                    e1.printStackTrace();
                }
            }

        }
    }

    private static void autoLaunchVivo(Context context) {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.iqoo.secure",
                    "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"));
            context.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName("com.vivo.permissionmanager",
                        "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
                context.startActivity(intent);
            } catch (Exception ex) {
                try {
                    Intent intent = new Intent();
                    intent.setClassName("com.iqoo.secure",
                            "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager");
                    context.startActivity(intent);
                } catch (Exception exx) {
                    ex.printStackTrace();
                }
            }
        }
    }


      private void autoStartForOppo () {
          try {
              Intent intent = new Intent();
              intent.setClassName("com.coloros.safecenter",
                      "com.coloros.safecenter.permission.startup.StartupAppListActivity");
              startActivity(intent);
          } catch (Exception e) {
              try {
                  Intent intent = new Intent();
                  intent.setClassName("com.oppo.safe",
                          "com.oppo.safe.permission.startup.StartupAppListActivity");
                  startActivity(intent);

              } catch (Exception ex) {
                  try {
                      Intent intent = new Intent();
                      intent.setClassName("com.coloros.safecenter",
                              "com.coloros.safecenter.startupapp.StartupAppListActivity");
                      startActivity(intent);
                  } catch (Exception exx) {

                  }
              }
          }
      }

    public void openSetting(View view) {
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);
    }

    public void openTheme(View view) {
    }
}