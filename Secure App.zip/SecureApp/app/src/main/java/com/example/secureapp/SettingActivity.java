package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Set;

public class SettingActivity extends AppCompatActivity {
    ImageView imageView;
    ArrayList<ActivityManager.RunningServiceInfo> runningServiceInfos;
    RelativeLayout relativeLayout;
    TextView lockTypeStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        imageView = findViewById(R.id.realtime_protection_toggle);
        relativeLayout = findViewById(R.id.realtime_protection_view);
        lockTypeStatus = findViewById(R.id.lock_type_status);
        SharedPreferences sharedPreferences = getSharedPreferences(getResources().getString(R.string.myAppSharedPreferences), Context.MODE_PRIVATE);
        String lockypeStatus = sharedPreferences.getString("lock_type", "No Lock Is Set");
        lockTypeStatus.setText(lockypeStatus.toUpperCase());
        if (isMyServiceRunning(ForegroundService.class)){
            imageView.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));
        }else{
            imageView.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
        }
        Intent serviceIntent = new Intent(getApplicationContext(), ForegroundService.class);
        relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isMyServiceRunning(ForegroundService.class)){
                    stopService(serviceIntent);
                    imageView.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.unlock_toggle, null));
                }else{
                    ContextCompat.startForegroundService(getApplicationContext(), serviceIntent);
                    imageView.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.locked_toggle, null));
                }
            }
        });
    }

    public void finishActivity(View view) {
        finish();
    }

    public void openUnlockSetting(View view) {
        Intent intent = new Intent(SettingActivity.this, lock_settings.class);
        startActivity(intent);
    }

    private boolean isMyServiceRunning (Class<?> serviceClass) {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo serviceInfo: activityManager.getRunningServices(Integer.MAX_VALUE)){
            if (serviceClass.getName().equalsIgnoreCase(serviceInfo.service.getClassName())){
                return true;
            }else{
                return false;
            }
        }

        return false;
    }

    public void openPatternLockChoosingActivity(View view) {
    }
}