package com.example.secureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ThemeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theme);
    }
}