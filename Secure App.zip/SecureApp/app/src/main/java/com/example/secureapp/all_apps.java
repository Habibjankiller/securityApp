package com.example.secureapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link all_apps#newInstance} factory method to
 * create an instance of this fragment.
 */
public class all_apps extends Fragment {
    private RecyclerView recyclerView;
    private RecyclerViewAdaptor recyclerViewAdaptor;
    private ArrayList<ApplicationInfo> filteredApplicationInfo;
    private PackageManager packageManager;
    private ArrayList<ApplicationInfo> allApplicationInfos;
    private SQLiteDatabase sqLiteDatabase;
    private AppInfoDbHelper appInfoDbHelper;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public all_apps() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment all_apps.
     */
    // TODO: Rename and change types and number of parameters
    public static all_apps newInstance(String param1, String param2) {
        all_apps fragment = new all_apps();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @SuppressLint("NewApi")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_all_apps, container, false);

        //Variables Initilization
        packageManager = getContext().getPackageManager();
        allApplicationInfos = (ArrayList<ApplicationInfo>) packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
        appInfoDbHelper = new AppInfoDbHelper(getContext());
        sqLiteDatabase = appInfoDbHelper.getWritableDatabase();

        filteredApplicationInfo = new ArrayList<>();
        recyclerView = view.findViewById(R.id.recycler_view);

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                for (ApplicationInfo applicationInfo: allApplicationInfos){
                    //Getting only filter application (Applications with Launcher Intent);
                    if (packageManager.getLaunchIntentForPackage(applicationInfo.packageName) != null){
                        filteredApplicationInfo.add(applicationInfo);
                    }
                }

                if (Build.VERSION.SDK_INT >= 24){
                    filteredApplicationInfo.sort(new Comparator<ApplicationInfo>() {
                        @Override
                        public int compare(ApplicationInfo o1, ApplicationInfo o2) {
                            String firstAppName = o1.loadLabel(packageManager).toString();
                            String secondAppName = o2.loadLabel(packageManager).toString();
                            return String.CASE_INSENSITIVE_ORDER.compare(firstAppName, secondAppName);
                        }
                    });
                }else{
                    Collections.sort(filteredApplicationInfo, new Comparator<ApplicationInfo>() {
                        @Override
                        public int compare(ApplicationInfo o1, ApplicationInfo o2) {
                            String firstAppName = o1.loadLabel(packageManager).toString();
                            String secondAppName = o2.loadLabel(packageManager).toString();
                            return String.CASE_INSENSITIVE_ORDER.compare(firstAppName, secondAppName);
                        }
                    });
                }
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdaptor = new RecyclerViewAdaptor(getContext(), filteredApplicationInfo, packageManager, sqLiteDatabase);
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
                        recyclerView.setLayoutManager(linearLayoutManager);
                        recyclerView.setAdapter(recyclerViewAdaptor);
                    }
                });
            }
        });


        return view;
    }
}