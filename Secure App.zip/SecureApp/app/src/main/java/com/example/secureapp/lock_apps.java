package com.example.secureapp;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link lock_apps#newInstance} factory method to
 * create an instance of this fragment.
 */
public class lock_apps extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private PackageManager packageManager;
    private ArrayList<ApplicationInfo> applicationInfos;
    AppInfoDbHelper sqLiteOpenHelper;
    SQLiteDatabase sqLiteDatabase;
    private RecyclerView recyclerView;
    private LockedAppsAdaptor lockedAppsAdaptor;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public lock_apps() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment lock_apps.
     */
    // TODO: Rename and change types and number of parameters
    public static lock_apps newInstance(String param1, String param2) {
        lock_apps fragment = new lock_apps();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_lock_apps, container, false);
        recyclerView = view.findViewById(R.id.locked_apps_recycler_view);


        packageManager = getContext().getPackageManager();
        sqLiteOpenHelper = new AppInfoDbHelper(getContext());
        sqLiteDatabase = sqLiteOpenHelper.getReadableDatabase();
        applicationInfos = new ArrayList<>();


        String SQL_QUERY_LOCKED_APPS = "SELECT "+ AppInfoDbHelper.AppEntry.COLUMN_APP_NAME +", "
                + AppInfoDbHelper.AppEntry.COLUMN_APP_PKGNAME
                +" FROM "+ AppInfoDbHelper.AppEntry.TABLE_NAME;

        Cursor lockedAppsCursor = sqLiteDatabase.rawQuery(SQL_QUERY_LOCKED_APPS, null);
        if (lockedAppsCursor.getCount() > 0){
            while (lockedAppsCursor.moveToNext()){
                String packageName = lockedAppsCursor.getString(1);
                try {
                    ApplicationInfo applicationInfo = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
                    applicationInfos.add(applicationInfo);
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
        Toast.makeText(getContext(), "there are total of "+lockedAppsCursor.getCount()+" of apps", Toast.LENGTH_SHORT).show();
        lockedAppsAdaptor = new LockedAppsAdaptor(getContext(), applicationInfos, packageManager, sqLiteDatabase);
        recyclerView.setAdapter(lockedAppsAdaptor);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        return view;
    }
}